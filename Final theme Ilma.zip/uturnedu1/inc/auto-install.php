<?php
/**
 * UTurnEdu1 Zero-Configuration Auto-Installer
 *
 * Automatically provisions all pages, menus, custom post types starter content,
 * homepage configuration, consultation slots, and options on theme activation.
 *
 * @package UTurnEdu1
 */

if (!defined('ABSPATH')) {
    exit;
}

function uturnedu_run_auto_installer($force = false) {
    $current_version = get_option('uturnedu_setup_version');
    $target_version  = '1.0.0';

    if (!$force && $current_version === $target_version) {
        return;
    }

    // 1. Create Core Pages
    $pages = [
        'home' => [
            'title'     => 'Home',
            'slug'      => 'home',
            'template'  => 'front-page.php',
            'content'   => 'Welcome to ILMA Education Consultancy - Study Abroad, See the World, Build Career!'
        ],
        'about' => [
            'title'     => 'About Us',
            'slug'      => 'about',
            'template'  => 'page-about.php',
            'content'   => 'ILMA Education Consultancy has been empowering students since 2013 from Mohammadpur, Dhaka.'
        ],
        'destinations' => [
            'title'     => 'Study Destinations',
            'slug'      => 'destinations',
            'template'  => 'archive-destination.php',
            'content'   => 'Explore top global education destinations: Canada, USA, UK, Australia, Malaysia, New Zealand.'
        ],
        'services' => [
            'title'     => 'Our Services',
            'slug'      => 'services',
            'template'  => 'archive-service.php',
            'content'   => 'Comprehensive, 100% free education consultancy services tailored to your academic dreams.'
        ],
        'reserve-consultation' => [
            'title'     => 'Reserve In-Person Consultation',
            'slug'      => 'reserve-consultation',
            'template'  => 'page-reserve-consultation.php',
            'content'   => 'Book your 1-on-1 personalized profile evaluation with senior certified counselors at our office.'
        ],
        'blogs' => [
            'title'     => 'Blog & News',
            'slug'      => 'blogs',
            'template'  => 'index.php',
            'content'   => 'Latest study abroad guides, visa updates, university admission tips, and student stories.'
        ],
        'contact' => [
            'title'     => 'Contact Us',
            'slug'      => 'contact',
            'template'  => 'page-contact.php',
            'content'   => 'Get in touch with Us Education Consultancy in Mohammadpur, Dhaka.'
        ],
        'privacy-policy' => [
            'title'     => 'Privacy Policy',
            'slug'      => 'privacy-policy',
            'template'  => 'page-legal.php',
            'content'   => 'At ILMA Education Consultancy, accessible from ilmaedubd.com, your privacy is one of our main priorities.'
        ],
        'terms-conditions' => [
            'title'     => 'Terms & Conditions',
            'slug'      => 'terms-conditions',
            'template'  => 'page-legal.php',
            'content'   => 'These Terms & Conditions outline the rules and regulations for the use of ILMA Education Consultancy\'s Website.'
        ],
        'cookie-policy' => [
            'title'     => 'Cookie Policy',
            'slug'      => 'cookie-policy',
            'template'  => 'page-legal.php',
            'content'   => 'This Cookie Policy explains how ILMA Education Consultancy uses cookies and similar technologies.'
        ],
        'disclaimer' => [
            'title'     => 'Disclaimer',
            'slug'      => 'disclaimer',
            'template'  => 'page-legal.php',
            'content'   => 'The information provided by ILMA Education Consultancy on ilmaedubd.com is for general informational purposes only.'
        ],
        'refund-policy' => [
            'title'     => 'Refund Policy',
            'slug'      => 'refund-policy',
            'template'  => 'page-legal.php',
            'content'   => 'ILMA Education Consultancy provides 100% free guidance and transparent policies regarding third-party university fees.'
        ],
    ];

    $created_page_ids = [];

    foreach ($pages as $key => $page_info) {
        $existing = get_page_by_path($page_info['slug']);
        if (!$existing) {
            $page_id = wp_insert_post([
                'post_title'    => $page_info['title'],
                'post_name'     => $page_info['slug'],
                'post_content'  => $page_info['content'],
                'post_status'   => 'publish',
                'post_type'     => 'page',
            ]);
            if ($page_id && !is_wp_error($page_id)) {
                if (!empty($page_info['template'])) {
                    update_post_meta($page_id, '_wp_page_template', $page_info['template']);
                }
                $created_page_ids[$key] = $page_id;
            }
        } else {
            $created_page_ids[$key] = $existing->ID;
            if (!empty($page_info['template'])) {
                update_post_meta($existing->ID, '_wp_page_template', $page_info['template']);
            }
        }
    }

    // Set Reading Settings (Static front page & posts page)
    if (!empty($created_page_ids['home'])) {
        update_option('show_on_front', 'page');
        update_option('page_on_front', $created_page_ids['home']);
    }
    if (!empty($created_page_ids['blogs'])) {
        update_option('page_for_posts', $created_page_ids['blogs']);
    }

    // 2. Setup Menus
    $menu_name = 'Primary Menu';
    $menu_exists = wp_get_nav_menu_object($menu_name);

    if (!$menu_exists) {
        $menu_id = wp_create_nav_menu($menu_name);

        if (!is_wp_error($menu_id)) {
            // Add items
            $nav_items = [
                ['title' => 'Home', 'url' => home_url('/')],
                ['title' => 'About Us', 'url' => home_url('/about/')],
                ['title' => 'Destinations', 'url' => home_url('/destinations/')],
                ['title' => 'Services', 'url' => home_url('/services/')],
                ['title' => 'Reserve Consultation', 'url' => home_url('/reserve-consultation/')],
                ['title' => 'Blog', 'url' => home_url('/blogs/')],
                ['title' => 'Contact', 'url' => home_url('/contact/')],
            ];

            foreach ($nav_items as $item) {
                wp_update_nav_menu_item($menu_id, 0, [
                    'menu-item-title'   => $item['title'],
                    'menu-item-url'     => $item['url'],
                    'menu-item-status'  => 'publish',
                    'menu-item-type'    => 'custom',
                ]);
            }

            // Assign to location
            $locations = get_theme_mod('nav_menu_locations');
            $locations['primary-menu'] = $menu_id;
            set_theme_mod('nav_menu_locations', $locations);
        }
    }

    // 3. Populate Starter Destinations
    $destinations_data = [
        [
            'title'       => 'Canada',
            'slug'        => 'canada',
            'flag'        => '🇨🇦',
            'code'        => 'CA',
            'capital'     => 'Ottawa',
            'currency'    => 'CAD ($)',
            'tuition'     => '$16,000 - $35,000 / year',
            'living'      => '$10,000 - $14,000 / year',
            'intakes'     => 'Fall (September), Winter (January), Summer (May)',
            'work_rights' => '20 hrs/week during semesters, 40 hrs/week scheduled breaks',
            'psw'         => 'Up to 3-Year Post-Graduation Work Permit (PGWP)',
            'ielts'       => 'Overall 6.0 (Undergrad), 6.5 (Postgrad) - SDS Eligible',
            'visa_rate'   => '98.5%',
            'universities'=> 'University of Toronto, University of Windsor, Memorial University, Seneca College, Humber College, Centennial College',
            'content'     => "Canada stands as one of the top destinations for Bangladeshi students seeking world-class education, affordable tuition, multicultural warmth, and clear pathways to post-graduation work and permanent residency.\n\n### Why Choose Canada?\n- World-renowned academic institutions with globally accredited degrees\n- Post-Graduation Work Permit (PGWP) allowing up to 3 years of work experience\n- Direct pathways to Permanent Residency (Express Entry & Provincial Nominee Programs)\n- Safe, peaceful, and welcoming multicultural society",
        ],
        [
            'title'       => 'United States of America',
            'slug'        => 'usa',
            'flag'        => '🇺🇸',
            'code'        => 'US',
            'capital'     => 'Washington, D.C.',
            'currency'    => 'USD ($)',
            'tuition'     => '$18,000 - $45,000 / year',
            'living'      => '$12,000 - $18,000 / year',
            'intakes'     => 'Fall (August/September), Spring (January), Summer (May)',
            'work_rights' => '20 hrs/week on-campus during terms, CPT/OPT available',
            'psw'         => '1 to 3 Years OPT (STEM Extensions available)',
            'ielts'       => 'Overall 6.0 - 6.5 (Duolingo & TOEFL widely accepted)',
            'visa_rate'   => '96.2%',
            'universities'=> 'Arizona State University, University of South Florida, Illinois Institute of Technology, Pace University, Kent State University',
            'content'     => "The United States is home to the world's most prestigious universities and research powerhouses. With flexible academic curriculums, immense scholarship opportunities, and vibrant campus life, studying in the USA opens unparalleled global career opportunities.\n\n### Why Choose the USA?\n- World's top-ranked universities and STEM research opportunities\n- Generous merit-based scholarships and graduate assistantships (GA/TA)\n- Up to 36 months of Optional Practical Training (OPT) for STEM graduates",
        ],
        [
            'title'       => 'United Kingdom',
            'slug'        => 'uk',
            'flag'        => '🇬🇧',
            'code'        => 'UK',
            'capital'     => 'London',
            'currency'    => 'GBP (£)',
            'tuition'     => '£11,000 - £22,000 / year',
            'living'      => '£9,000 - £12,000 / year',
            'intakes'     => 'September/October, January/February, May/June',
            'work_rights' => '20 hrs/week during term-time, full-time during vacations',
            'psw'         => '2-Year Graduate Route Visa (3 Years for PhD)',
            'ielts'       => 'Overall 6.0 (MOI & internal English tests accepted)',
            'visa_rate'   => '99.1%',
            'universities'=> 'University of Greenwich, University of Hertfordshire, Coventry University, University of Portsmouth, Northumbria University',
            'content'     => "The UK offers shorter degree durations (1-year Master's, 3-year Bachelor's) providing extraordinary value for time and money. With historic Russell Group institutions and dynamic modern universities, the UK remains a favorite destination for Bangladeshi learners.\n\n### Why Choose the UK?\n- 1-Year Master's degrees cut tuition and living expenses in half\n- 2-Year Graduate Route post-study work visa without employer sponsorship\n- High visa success rates and MOI waiver options for qualifying institutions",
        ],
        [
            'title'       => 'Australia',
            'slug'        => 'australia',
            'flag'        => '🇦🇺',
            'code'        => 'AU',
            'capital'     => 'Canberra',
            'currency'    => 'AUD ($)',
            'tuition'     => '$20,000 - $38,000 / year',
            'living'      => '$14,000 - $19,000 / year',
            'intakes'     => 'February (Semester 1), July (Semester 2), November',
            'work_rights' => '48 hrs per fortnight during study terms, full-time in holidays',
            'psw'         => '2 to 4 Years Post-Study Work Visa (Subclass 485)',
            'ielts'       => 'Overall 6.0 - 6.5 (PTE Academic widely preferred)',
            'visa_rate'   => '95.8%',
            'universities'=> 'Deakin University, Victoria University, Western Sydney University, Curtin University, CQUniversity',
            'content'     => "Australia combines prestigious Group of Eight research institutions with high minimum wages, incredible quality of life, and generous post-study work entitlements in regional and major metropolitan hubs.\n\n### Why Choose Australia?\n- Globally recognized qualification framework (AQF)\n- Highest international student minimum wage rates worldwide\n- Extended post-study work streams in regional areas",
        ],
        [
            'title'       => 'Malaysia',
            'slug'        => 'malaysia',
            'flag'        => '🇲🇾',
            'code'        => 'MY',
            'capital'     => 'Kuala Lumpur',
            'currency'    => 'MYR (RM)',
            'tuition'     => '$3,500 - $8,000 / year',
            'living'      => '$3,000 - $5,000 / year',
            'intakes'     => 'February, April, September, November',
            'work_rights' => 'Allowed during semester breaks in specified sectors',
            'psw'         => 'Direct credit transfer & international branch campus options',
            'ielts'       => 'Overall 5.5 (Many universities offer on-campus EAP)',
            'visa_rate'   => '99.4%',
            'universities'=> 'Taylor\'s University, Sunway University, APU (Asia Pacific University), UCSI University, INTI International University',
            'content'     => "Malaysia offers an affordable gateway to UK and Australian dual degrees right in Asia. Low tuition fees, cost-effective living, hassle-free EMGS visa processing, and Muslim-friendly lifestyle make Malaysia hugely attractive.\n\n### Why Choose Malaysia?\n- 3+0 and 2+1 twinning programs with UK and Australian Universities\n- Ultra-affordable living expenses and modern smart campuses\n- 99%+ fast-track EMGS student visa approval rates",
        ],
        [
            'title'       => 'New Zealand',
            'slug'        => 'new-zealand',
            'flag'        => '🇳🇿',
            'code'        => 'NZ',
            'capital'     => 'Wellington',
            'currency'    => 'NZD ($)',
            'tuition'     => '$18,000 - $32,000 / year',
            'living'      => '$11,000 - $15,000 / year',
            'intakes'     => 'February, July, October',
            'work_rights' => '20 hrs/week during study, full-time during holidays',
            'psw'         => 'Up to 3-Year Post-Study Work Visa',
            'ielts'       => 'Overall 6.0 - 6.5',
            'visa_rate'   => '96.0%',
            'universities'=> 'University of Auckland, University of Otago, AUT University, Lincoln University, Massey University',
            'content'     => "New Zealand offers top-tier education in one of the world's safest and most scenic countries. Every single university in NZ is ranked in the top 3% globally by QS Rankings, offering hands-on practical research and great post-study work opportunities.\n\n### Why Choose New Zealand?\n- 100% of New Zealand universities are ranked in the global Top 500\n- High standard of living, safety, and student welfare\n- Up to 3-year post study open work visas for Bachelor & Master degrees",
        ],
    ];

    foreach ($destinations_data as $dest) {
        $existing = get_page_by_path($dest['slug'], OBJECT, 'destination');
        if (!$existing) {
            $post_id = wp_insert_post([
                'post_title'   => $dest['title'],
                'post_name'    => $dest['slug'],
                'post_content' => $dest['content'],
                'post_status'  => 'publish',
                'post_type'    => 'destination',
            ]);
            if ($post_id && !is_wp_error($post_id)) {
                update_post_meta($post_id, '_dest_flag', $dest['flag']);
                update_post_meta($post_id, '_dest_code', $dest['code']);
                update_post_meta($post_id, '_dest_capital', $dest['capital']);
                update_post_meta($post_id, '_dest_currency', $dest['currency']);
                update_post_meta($post_id, '_dest_tuition', $dest['tuition']);
                update_post_meta($post_id, '_dest_living_cost', $dest['living']);
                update_post_meta($post_id, '_dest_intakes', $dest['intakes']);
                update_post_meta($post_id, '_dest_work_rights', $dest['work_rights']);
                update_post_meta($post_id, '_dest_psw', $dest['psw']);
                update_post_meta($post_id, '_dest_ielts', $dest['ielts']);
                update_post_meta($post_id, '_dest_visa_rate', $dest['visa_rate']);
                update_post_meta($post_id, '_dest_universities', $dest['universities']);
            }
        }
    }

    // 4. Populate Starter Services
    $services_data = [
        [
            'title'   => 'Student Visa Application Guidance',
            'slug'    => 'student-visa-application-guidance',
            'icon'    => '✈️',
            'badge'   => 'High Success Rate',
            'process' => "1. Financial Assessment & Document Verification\n2. SOP & Cover Letter Formulation\n3. Biometrics & Embassy Interview Mock Prep\n4. Visa Submission & Tracking",
            'content' => "Navigating international visa requirements can be complex. ILMA Education Consultancy provides step-by-step guidance, rigorous financial documentation checks, mock interview training, and genuine SOP reviews ensuring 98%+ success.",
        ],
        [
            'title'   => 'University & Course Selection',
            'slug'    => 'university-course-selection',
            'icon'    => '🎓',
            'badge'   => '100% Free',
            'process' => "1. Academic & Budget Profile Analysis\n2. Country & Course Shortlisting\n3. Intake Timeline Planning\n4. Application Submission to Multiple Partner Unis",
            'content' => "With 100+ partner universities across Canada, USA, UK, Australia, Malaysia, and New Zealand, our certified counselors help you choose the right course aligned with your academic background and future career goals.",
        ],
        [
            'title'   => 'Scholarship & Financial Aid Assistance',
            'slug'    => 'scholarship-assistance',
            'icon'    => '💰',
            'badge'   => 'Max Funding',
            'process' => "1. Scholarship Criteria Matching\n2. Essay & Portfolio Review\n3. Direct Faculty Application Guidance\n4. Award Letter Confirmation",
            'content' => "We identify and assist students in applying for generous merit-based scholarships, early bird fee waivers, international student bursaries, and graduate assistantships.",
        ],
        [
            'title'   => 'Career Counseling & Profile Evaluation',
            'slug'    => 'career-counseling',
            'icon'    => '🧭',
            'badge'   => '1-on-1 Mentorship',
            'process' => "1. In-depth 1-on-1 Consultation Session\n2. Skillset & Passion Mapping\n3. Global Employment Trends Review\n4. Personalized Academic Roadmap",
            'content' => "Our senior counselors evaluate your academic transcripts, English proficiency, career aspirations, and financial plan to craft a transparent, step-by-step higher study pathway.",
        ],
        [
            'title'   => 'SOP, Resume & Documentation Support',
            'slug'    => 'sop-documentation-support',
            'icon'    => '📄',
            'badge'   => 'Zero Plagiarism',
            'process' => "1. Questionnaire & Background Gathering\n2. Structure & Narrative Crafting\n3. Professional Proofreading\n4. Final Customized SOP Ready for Submission",
            'content' => "A compelling Statement of Purpose (SOP) and well-structured CV are critical for admissions and visa grants. We assist in shaping your authentic personal story into an impactful application.",
        ],
        [
            'title'   => 'Pre-Departure Briefing & Accommodation',
            'slug'    => 'pre-departure-briefing',
            'icon'    => '🌍',
            'badge'   => 'Complete Care',
            'process' => "1. Flight Booking & Baggage Rules Briefing\n2. On-Campus vs Off-Campus Housing Booking\n3. SIM Card & Bank Account Setup Advice\n4. Port of Entry Immigration Guidelines",
            'content' => "Our support extends right until you settle comfortably in your destination country. We organize comprehensive pre-departure sessions covering travel tips, accommodation arrangements, and foreign banking advice.",
        ],
    ];

    foreach ($services_data as $srv) {
        $existing = get_page_by_path($srv['slug'], OBJECT, 'service');
        if (!$existing) {
            $post_id = wp_insert_post([
                'post_title'   => $srv['title'],
                'post_name'    => $srv['slug'],
                'post_content' => $srv['content'],
                'post_status'  => 'publish',
                'post_type'    => 'service',
            ]);
            if ($post_id && !is_wp_error($post_id)) {
                update_post_meta($post_id, '_service_icon', $srv['icon']);
                update_post_meta($post_id, '_service_badge', $srv['badge']);
                update_post_meta($post_id, '_service_process', $srv['process']);
            }
        }
    }

    // 5. Populate Starter Testimonials
    $testimonials_data = [
        [
            'title'      => 'Tanvir Ahmed',
            'country'    => 'Canada',
            'university' => 'University of Windsor',
            'program'    => 'Master of Applied Computing',
            'rating'     => '5',
            'content'    => 'ILMA Education Consultancy made my Canadian student visa journey completely seamless! From admission to visa approval, Rawshan Sir and the team guided me with immense patience and professionalism.',
        ],
        [
            'title'      => 'Nusrat Jahan',
            'country'    => 'United Kingdom',
            'university' => 'University of Greenwich',
            'program'    => 'MSc Data Science & AI',
            'rating'     => '5',
            'content'    => 'I received my UK CAS letter and Visa in record time! Their Mohammadpur office counselors are exceptionally knowledgeable and gave me honest advice at zero consultancy cost.',
        ],
        [
            'title'      => 'Shakil Mahmud',
            'country'    => 'Australia',
            'university' => 'Deakin University',
            'program'    => 'Bachelor of Business Information Systems',
            'rating'     => '5',
            'content'    => 'Best education agency in Dhaka. They assisted me with genuine GTE documentation and scholarship application. Highly recommended for anyone dreaming of studying in Australia.',
        ],
        [
            'title'      => 'Farhana Rahman',
            'country'    => 'USA',
            'university' => 'Illinois Institute of Technology',
            'program'    => 'Master of Science in Electrical Engineering',
            'rating'     => '5',
            'content'    => 'The mock visa interview sessions provided by ILMA Education Consultancy gave me immense confidence for my US Embassy appointment. I got my F-1 visa approved on the very first try!',
        ],
    ];

    foreach ($testimonials_data as $testi) {
        $existing = get_page_by_path(sanitize_title($testi['title']), OBJECT, 'testimonial');
        if (!$existing) {
            $post_id = wp_insert_post([
                'post_title'   => $testi['title'],
                'post_name'    => sanitize_title($testi['title']),
                'post_content' => $testi['content'],
                'post_status'  => 'publish',
                'post_type'    => 'testimonial',
            ]);
            if ($post_id && !is_wp_error($post_id)) {
                update_post_meta($post_id, '_testi_country', $testi['country']);
                update_post_meta($post_id, '_testi_university', $testi['university']);
                update_post_meta($post_id, '_testi_program', $testi['program']);
                update_post_meta($post_id, '_testi_rating', $testi['rating']);
            }
        }
    }

    // 6. Populate Starter Counselors
    $counselors_data = [
        [
            'title'     => 'Rawshan Ara',
            'role'      => 'Senior Principal Counselor & Founder',
            'exp'       => '11+ Years Experience',
            'countries' => 'Canada, UK, USA',
            'email'     => 'rawshan@ilmaedubd.com',
            'phone'     => '+880 1823-345573',
        ],
        [
            'title'     => 'Md. Zahid Hassan',
            'role'      => 'UK & Australia Lead Specialist',
            'exp'       => '8+ Years Experience',
            'countries' => 'UK, Australia, New Zealand',
            'email'     => 'zahid@ilmaedubd.com',
            'phone'     => '+880 1329-272046',
        ],
        [
            'title'     => 'Sadia Afrin',
            'role'      => 'North America & Scholarship Advisor',
            'exp'       => '6+ Years Experience',
            'countries' => 'USA, Canada',
            'email'     => 'sadia@ilmaedubd.com',
            'phone'     => '+880 1848-638406',
        ],
        [
            'title'     => 'Kazi Arman',
            'role'      => 'Asian Hubs & Fast-Track Specialist',
            'exp'       => '5+ Years Experience',
            'countries' => 'Malaysia, Europe',
            'email'     => 'arman@ilmaedubd.com',
            'phone'     => '+880 1329-272046',
        ],
    ];

    foreach ($counselors_data as $coun) {
        $existing = get_page_by_path(sanitize_title($coun['title']), OBJECT, 'counselor');
        if (!$existing) {
            $post_id = wp_insert_post([
                'post_title'   => $coun['title'],
                'post_name'    => sanitize_title($coun['title']),
                'post_status'  => 'publish',
                'post_type'    => 'counselor',
            ]);
            if ($post_id && !is_wp_error($post_id)) {
                update_post_meta($post_id, '_counselor_role', $coun['role']);
                update_post_meta($post_id, '_counselor_exp', $coun['exp']);
                update_post_meta($post_id, '_counselor_countries', $coun['countries']);
                update_post_meta($post_id, '_counselor_email', $coun['email']);
                update_post_meta($post_id, '_counselor_phone', $coun['phone']);
            }
        }
    }

    // 7. Populate Starter Consultation Slots (Monday - Saturday intervals)
    $slots_data = [
        ['start' => '10:00 AM', 'end' => '11:30 AM', 'cap' => 4, 'counselor' => 'Senior Canada Counselor'],
        ['start' => '11:30 AM', 'end' => '01:00 PM', 'cap' => 4, 'counselor' => 'Senior UK Counselor'],
        ['start' => '02:00 PM', 'end' => '03:30 PM', 'cap' => 4, 'counselor' => 'USA & Scholarship Lead'],
        ['start' => '03:30 PM', 'end' => '05:00 PM', 'cap' => 4, 'counselor' => 'Australia & New Zealand Specialist'],
        ['start' => '05:00 PM', 'end' => '06:30 PM', 'cap' => 3, 'counselor' => 'Senior Admission Director'],
    ];

    $existing_slots = get_posts(['post_type' => 'consult_slot', 'numberposts' => 1]);
    if (empty($existing_slots)) {
        foreach ($slots_data as $s) {
            $slot_title = "Slot: {$s['start']} - {$s['end']} ({$s['counselor']})";
            $post_id = wp_insert_post([
                'post_title'  => $slot_title,
                'post_status' => 'publish',
                'post_type'   => 'consult_slot',
            ]);
            if ($post_id && !is_wp_error($post_id)) {
                update_post_meta($post_id, '_slot_start_time', $s['start']);
                update_post_meta($post_id, '_slot_end_time', $s['end']);
                update_post_meta($post_id, '_slot_capacity', $s['cap']);
                update_post_meta($post_id, '_slot_counselor_name', $s['counselor']);
                update_post_meta($post_id, '_slot_active', 'yes');
            }
        }
    }

    // 8. Populate Starter Blog Posts
    $blogs_data = [
        [
            'title'   => 'Best University in UK for Bangladeshi Students: Complete 2026 Guide',
            'slug'    => 'best-university-in-uk-2026',
            'content' => "Choosing the right university in the United Kingdom is a life-changing decision for students from Bangladesh. In this comprehensive guide, we cover ranking factors, affordable tuition fees, MOI waivers, and the 2-Year Graduate Route post-study work visa.\n\n### Top Factors to Consider:\n1. Location & Living Costs: London vs Regional cities like Portsmouth, Coventry, and Newcastle.\n2. Admission Requirements: Many UK universities accept Medium of Instruction (MOI) certificates from accredited Bangladeshi universities.\n3. Career Prospects: Look for universities with strong employability rates and internship modules.",
        ],
        [
            'title'   => 'How to Prepare for Higher Study Abroad: 7 Step Roadmap',
            'slug'    => 'how-to-prepare-for-higher-study-abroad',
            'content' => "Starting your study abroad journey early gives you the best chance of scoring top scholarships and getting your visa on time. Follow this 7-step proven roadmap formulated by ILMA Education counselors.\n\n### The 7 Steps:\n1. Transcript & Certificate Preparation\n2. IELTS / PTE / Duolingo Preparation\n3. Country & University Matching\n4. Recommendation Letters & SOP Drafting\n5. Financial Planning & Bank Statement Readiness\n6. Application Submission across Multiple Intakes\n7. Visa File Processing & Mock Interviews",
        ],
        [
            'title'   => 'Get Tuition-Free & High Scholarship Opportunities in Canada',
            'slug'    => 'tuition-free-scholarships-canada',
            'content' => "While studying in Canada requires investment, hundreds of merit-based scholarships, research assistantships (RA), and university entrance grants can significantly lower your expenses.\n\n### Key Canadian Scholarships:\n- University of Toronto Lester B. Pearson International Scholarship\n- University of Windsor International Entrance Awards\n- Memorial University Graduate Fellowships\n- Ontario Graduate Scholarship (OGS)",
        ],
    ];

    foreach ($blogs_data as $b) {
        $existing = get_page_by_path($b['slug'], OBJECT, 'post');
        if (!$existing) {
            wp_insert_post([
                'post_title'   => $b['title'],
                'post_name'    => $b['slug'],
                'post_content' => $b['content'],
                'post_status'  => 'publish',
                'post_type'    => 'post',
            ]);
        }
    }

    // 9. Populate Starter Ad Banners
    $existing_ads = get_posts(['post_type' => 'ad_banner', 'numberposts' => 1]);
    if (empty($existing_ads)) {
        $starter_ads = [
            [
                'title'     => 'September 2026 Major Intake Promo Banner',
                'placement' => 'home_middle',
                'url'       => home_url('/reserve-consultation/'),
                'image'     => get_template_directory_uri() . '/assets/images/home_banner.jpg',
            ],
            [
                'title'     => 'Header Flash Notice: 100% Free Consultation Days',
                'placement' => 'header_top',
                'url'       => home_url('/reserve-consultation/'),
                'image'     => '',
            ],
        ];
        foreach ($starter_ads as $ad) {
            $post_id = wp_insert_post([
                'post_title'  => $ad['title'],
                'post_status' => 'publish',
                'post_type'   => 'ad_banner',
            ]);
            if ($post_id && !is_wp_error($post_id)) {
                update_post_meta($post_id, '_ad_placement', $ad['placement']);
                update_post_meta($post_id, '_ad_target_url', $ad['url']);
                update_post_meta($post_id, '_ad_image_url', $ad['image']);
                update_post_meta($post_id, '_ad_active', 'yes');
                update_post_meta($post_id, '_ad_clicks', 0);
            }
        }
    }

    // 10. Populate Default UTurnEdu Theme Settings
    $default_settings = [
        'site_tagline'          => 'Study Abroad, See the World, Build Career!',
        'address'               => 'CL Tower, 772/1A, Bosila Road, Mohammadpur, Dhaka - 1207, Bangladesh',
        'office_area'           => 'Mohammadpur, Dhaka',
        'office_hours'          => 'Saturday – Thursday: 10:00 AM – 6:30 PM (Friday Closed)',
        'site_logo_transparent' => get_template_directory_uri() . '/assets/images/ILMA-Education-logo-transparent.png',
        'popup_type'            => 'image_and_text',
        'popup_image_url'       => get_template_directory_uri() . '/assets/images/scholarship-celebration.jpg',
        'phone_primary'         => '01329272046',
        'phone_secondary'       => '01823345573',
        'phone_hotline'         => '+880 1848-638406',
        'email_primary'         => 'info@ilmaedubd.com',
        'email_support'         => 'rawshan@ilmaedubd.com',
        'stat_universities'     => '100+',
        'stat_free_consult'     => '100%',
        'stat_successful_apps'  => '367+',
        'stat_counselors'       => '09+',
        'facebook_url'          => 'https://www.facebook.com/ilmaeducationbd',
        'instagram_url'         => 'https://www.instagram.com/ilmaeducation',
        'youtube_url'           => 'https://www.youtube.com/@ilmaeducation',
        'whatsapp_number'       => '+8801329272046',
        'popup_enabled'         => 'yes',
        'popup_delay'           => '5',
        'popup_heading'         => 'Start Your Study Abroad Journey with 100% Free Guidance!',
        'popup_subheading'      => 'Meet certified counselors at our office or get immediate profile assessment.',
        'popup_cta_text'        => 'Book Free Consultation',
        'popup_cta_action'      => 'modal',
        'popup_frequency'       => 'session',
    ];

    update_option('uturnedu_settings', $default_settings);
    update_option('uturnedu_setup_version', $target_version);
    update_option('uturnedu_installed', 1);
}

// Hook on theme activation
add_action('after_switch_theme', 'uturnedu_run_auto_installer');

// Check on admin init if setup is required
add_action('admin_init', function() {
    if (!get_option('uturnedu_setup_version')) {
        uturnedu_run_auto_installer();
    }
});
