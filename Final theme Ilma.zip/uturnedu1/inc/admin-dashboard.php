<?php
/**
 * UTurnEdu1 SaaS Admin Dashboard Engine & Management Suite
 *
 * @package UTurnEdu1
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Register Admin Menu Pages
 */
function uturnedu_register_admin_menu() {
    add_menu_page(
        __('ILMA Admin Dashboard', 'uturnedu1'),
        __('ILMA Admin Dashboard', 'uturnedu1'),
        'manage_options',
        'uturnedu_dashboard',
        'uturnedu_render_dashboard_page',
        'dashicons-superhero-alt',
        3
    );

    add_submenu_page(
        'uturnedu_dashboard',
        __('Overview & Stats', 'uturnedu1'),
        __('📊 Overview', 'uturnedu1'),
        'manage_options',
        'uturnedu_dashboard',
        'uturnedu_render_dashboard_page'
    );

    add_submenu_page(
        'uturnedu_dashboard',
        __('Content Studio', 'uturnedu1'),
        __('✦ Content Studio', 'uturnedu1'),
        'manage_options',
        'uturnedu_dashboard#tab-content',
        'uturnedu_render_dashboard_page'
    );

    add_submenu_page(
        'uturnedu_dashboard',
        __('Site Builder', 'uturnedu1'),
        __('🧩 Homepage Builder', 'uturnedu1'),
        'manage_options',
        'uturnedu_dashboard#tab-builder',
        'uturnedu_render_dashboard_page'
    );

    add_submenu_page(
        'uturnedu_dashboard',
        __('Leads CRM', 'uturnedu1'),
        __('📥 Leads CRM', 'uturnedu1'),
        'manage_options',
        'uturnedu_dashboard#tab-leads',
        'uturnedu_render_dashboard_page'
    );

    add_submenu_page(
        'uturnedu_dashboard',
        __('Forms & Submissions', 'uturnedu1'),
        __('▣ Forms & Submissions', 'uturnedu1'),
        'manage_options',
        'uturnedu_dashboard#tab-forms',
        'uturnedu_render_dashboard_page'
    );

    add_submenu_page(
        'uturnedu_dashboard',
        __('In-Person Bookings', 'uturnedu1'),
        __('📅 Bookings & Office Visits', 'uturnedu1'),
        'manage_options',
        'uturnedu_dashboard#tab-appointments',
        'uturnedu_render_dashboard_page'
    );

    add_submenu_page(
        'uturnedu_dashboard',
        __('Consultation Slots', 'uturnedu1'),
        __('⏰ Slots Manager', 'uturnedu1'),
        'manage_options',
        'uturnedu_dashboard#tab-slots',
        'uturnedu_render_dashboard_page'
    );

    add_submenu_page(
        'uturnedu_dashboard',
        __('Popup Campaigns', 'uturnedu1'),
        __('🎯 Popup Builder (Image & Text)', 'uturnedu1'),
        'manage_options',
        'uturnedu_dashboard#tab-popup',
        'uturnedu_render_dashboard_page'
    );

    add_submenu_page(
        'uturnedu_dashboard',
        __('Marketing Ad Spaces', 'uturnedu1'),
        __('📢 Ad Banner Spaces', 'uturnedu1'),
        'manage_options',
        'uturnedu_dashboard#tab-ads',
        'uturnedu_render_dashboard_page'
    );

    add_submenu_page(
        'uturnedu_dashboard',
        __('Agency, Office & Logo Settings', 'uturnedu1'),
        __('⚙️ Agency & Logo Settings', 'uturnedu1'),
        'manage_options',
        'uturnedu_dashboard#tab-settings',
        'uturnedu_render_dashboard_page'
    );
}
add_action('admin_menu', 'uturnedu_register_admin_menu');

/** Replace hash-based submenu slugs with real query-string URLs. */
function uturnedu_fix_dashboard_submenu_links() {
    global $submenu;
    if (empty($submenu['uturnedu_dashboard'])) {
        return;
    }
    foreach ($submenu['uturnedu_dashboard'] as &$item) {
        if (!empty($item[2]) && false !== strpos($item[2], '#tab-')) {
            $tab = substr($item[2], strpos($item[2], '#tab-') + 5);
            $item[2] = admin_url('admin.php?page=uturnedu_dashboard&tab=' . rawurlencode($tab));
        }
    }
}
add_action('admin_menu', 'uturnedu_fix_dashboard_submenu_links', 999);

/**
 * Handle Settings Form Submission
 */
function uturnedu_handle_settings_save() {
    if (!isset($_POST['uturnedu_save_settings_nonce']) || !wp_verify_nonce($_POST['uturnedu_save_settings_nonce'], 'uturnedu_save_settings_action')) {
        return;
    }
    if (!current_user_can('manage_options')) {
        return;
    }

    $existing = get_option('uturnedu_settings', []);
    $existing = is_array($existing) ? $existing : [];

    $settings = [
        // Branding & Logos
        'site_tagline'            => sanitize_text_field($_POST['site_tagline'] ?? ''),
        'site_logo_primary'       => esc_url_raw($_POST['site_logo_primary'] ?? ''),
        'site_logo_transparent'   => esc_url_raw($_POST['site_logo_transparent'] ?? ''),
        'site_logo_dashboard'     => esc_url_raw($_POST['site_logo_dashboard'] ?? ''),
        'site_favicon'            => esc_url_raw($_POST['site_favicon'] ?? ''),
        'about_story_image'       => esc_url_raw($_POST['about_story_image'] ?? ''),
        'about_admission_image'   => esc_url_raw($_POST['about_admission_image'] ?? ''),
        'about_visa_image'        => esc_url_raw($_POST['about_visa_image'] ?? ''),
        'about_asia_image'        => esc_url_raw($_POST['about_asia_image'] ?? ''),
        'about_hero_title'       => sanitize_text_field($_POST['about_hero_title'] ?? ''),
        'about_hero_intro'       => sanitize_textarea_field($_POST['about_hero_intro'] ?? ''),
        'contact_hero_title'     => sanitize_text_field($_POST['contact_hero_title'] ?? ''),
        'contact_hero_intro'     => sanitize_textarea_field($_POST['contact_hero_intro'] ?? ''),
        'apply_hero_title'       => sanitize_text_field($_POST['apply_hero_title'] ?? ''),
        'apply_hero_intro'       => sanitize_textarea_field($_POST['apply_hero_intro'] ?? ''),
        'reserve_hero_title'     => sanitize_text_field($_POST['reserve_hero_title'] ?? ''),
        'reserve_hero_intro'     => sanitize_textarea_field($_POST['reserve_hero_intro'] ?? ''),
        'services_hero_title'    => sanitize_text_field($_POST['services_hero_title'] ?? ''),
        'services_hero_intro'    => sanitize_textarea_field($_POST['services_hero_intro'] ?? ''),

        // Office Location & Contacts (Editable at any time)
        'address'                 => sanitize_text_field($_POST['address'] ?? 'CL Tower, 772/1A, Bosila Road, Mohammadpur, Dhaka - 1207, Bangladesh'),
        'office_area'             => sanitize_text_field($_POST['office_area'] ?? 'Mohammadpur, Dhaka'),
        'office_hours'            => sanitize_text_field($_POST['office_hours'] ?? 'Saturday – Thursday: 10:00 AM – 6:30 PM (Friday Closed)'),
        'phone_primary'           => sanitize_text_field($_POST['phone_primary'] ?? ''),
        'phone_secondary'         => sanitize_text_field($_POST['phone_secondary'] ?? ''),
        'phone_hotline'           => sanitize_text_field($_POST['phone_hotline'] ?? ''),
        'email_primary'           => sanitize_email($_POST['email_primary'] ?? ''),
        'email_support'           => sanitize_email($_POST['email_support'] ?? ''),
        'whatsapp_number'         => sanitize_text_field($_POST['whatsapp_number'] ?? ''),
        'form_notification_email' => sanitize_email($_POST['form_notification_email'] ?? ''),
        'form_auto_reply_enabled' => sanitize_text_field($_POST['form_auto_reply_enabled'] ?? 'no') === 'yes' ? 'yes' : 'no',
        'form_success_message'    => sanitize_textarea_field($_POST['form_success_message'] ?? 'Thank you. Our team will review your details and contact you shortly.'),
        'footer_description'      => sanitize_textarea_field($_POST['footer_description'] ?? ''),
        'footer_copyright'        => sanitize_text_field($_POST['footer_copyright'] ?? ''),

        // Stats & Badges
        'stat_universities'       => sanitize_text_field($_POST['stat_universities'] ?? ''),
        'stat_free_consult'       => sanitize_text_field($_POST['stat_free_consult'] ?? ''),
        'stat_successful_apps'    => sanitize_text_field($_POST['stat_successful_apps'] ?? ''),
        'stat_counselors'         => sanitize_text_field($_POST['stat_counselors'] ?? ''),

        // Social Accounts
        'facebook_url'            => esc_url_raw($_POST['facebook_url'] ?? ''),
        'instagram_url'           => esc_url_raw($_POST['instagram_url'] ?? ''),
        'youtube_url'             => esc_url_raw($_POST['youtube_url'] ?? ''),

        // Popup Builder (Textual / Image Only / Hybrid)
        'popup_enabled'           => sanitize_text_field($_POST['popup_enabled'] ?? 'yes'),
        'popup_type'              => sanitize_text_field($_POST['popup_type'] ?? 'image_and_text'), // textual | image_only | image_and_text
        'popup_image_url'         => esc_url_raw($_POST['popup_image_url'] ?? ''),
        'popup_delay'             => (int) ($_POST['popup_delay'] ?? 5),
        'popup_heading'           => sanitize_text_field($_POST['popup_heading'] ?? ''),
        'popup_subheading'        => sanitize_textarea_field($_POST['popup_subheading'] ?? ''),
        'popup_cta_text'          => sanitize_text_field($_POST['popup_cta_text'] ?? 'Claim Free Consultation'),
        'popup_cta_action'        => sanitize_text_field($_POST['popup_cta_action'] ?? 'modal'),
        'popup_cta_url'           => esc_url_raw($_POST['popup_cta_url'] ?? ''),
        'popup_frequency'         => sanitize_text_field($_POST['popup_frequency'] ?? 'session'),
    ];

    update_option('uturnedu_settings', array_merge($existing, $settings));

    // Handle Quick Starter Re-sync
    if (isset($_POST['reinstall_starter_content'])) {
        uturnedu_run_auto_installer(true);
        wp_redirect(admin_url('admin.php?page=uturnedu_dashboard&reinstalled=1'));
        exit;
    }

    wp_redirect(admin_url('admin.php?page=uturnedu_dashboard&updated=1'));
    exit;
}
add_action('admin_init', 'uturnedu_handle_settings_save');

/** Save the no-code homepage builder fields. */
function uturnedu_handle_homepage_content_save() {
    if (!isset($_POST['uturnedu_homepage_nonce']) || !wp_verify_nonce($_POST['uturnedu_homepage_nonce'], 'uturnedu_save_homepage_content')) {
        return;
    }
    if (!current_user_can('manage_options')) {
        return;
    }

    $text_fields = [
        'hero_kicker', 'hero_cta', 'hero_secondary_cta',
        'destination_kicker', 'destination_title', 'destination_intro',
        'why_kicker', 'why_title', 'why_intro', 'why_card_1_title', 'why_card_1_text', 'why_card_2_title', 'why_card_2_text', 'why_card_3_title', 'why_card_3_text', 'why_card_4_title', 'why_card_4_text',
        'services_kicker', 'services_title', 'services_intro',
        'process_kicker', 'process_title', 'process_intro', 'process_1_title', 'process_1_text', 'process_2_title', 'process_2_text', 'process_3_title', 'process_3_text', 'process_4_title', 'process_4_text',
        'eligibility_kicker', 'eligibility_title', 'eligibility_text', 'eligibility_cta',
        'contact_kicker', 'contact_title', 'contact_text', 'video_title', 'video_text',
    ];
    $content = [];
    foreach ($text_fields as $field) {
        $content[$field] = in_array($field, ['destination_intro', 'why_intro', 'why_card_1_text', 'why_card_2_text', 'why_card_3_text', 'why_card_4_text', 'services_intro', 'process_intro', 'process_1_text', 'process_2_text', 'process_3_text', 'process_4_text', 'eligibility_text', 'contact_text', 'video_text'], true)
            ? sanitize_textarea_field($_POST[$field] ?? '')
            : sanitize_text_field($_POST[$field] ?? '');
    }
    $content['video_enabled'] = sanitize_text_field($_POST['video_enabled'] ?? 'no') === 'yes' ? 'yes' : 'no';
    $content['video_url'] = esc_url_raw($_POST['video_url'] ?? '');
    $content['video_poster'] = esc_url_raw($_POST['video_poster'] ?? '');

    update_option('uturnedu_homepage_content', $content);
    wp_safe_redirect(admin_url('admin.php?page=uturnedu_dashboard&updated=1&tab=builder'));
    exit;
}
add_action('admin_init', 'uturnedu_handle_homepage_content_save');

/** Export CRM records as a spreadsheet-friendly CSV. */
function uturnedu_export_leads_csv() {
    if (!current_user_can('manage_options') || !check_admin_referer('uturnedu_export_leads')) {
        wp_die(esc_html__('You are not authorised to export leads.', 'uturnedu1'));
    }
    $leads = get_posts(['post_type' => 'lead', 'posts_per_page' => -1, 'post_status' => 'publish', 'orderby' => 'date', 'order' => 'DESC']);
    nocache_headers();
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=ilma-leads-' . gmdate('Y-m-d') . '.csv');
    $output = fopen('php://output', 'w');
    fputcsv($output, ['Name', 'Phone', 'Email', 'Country', 'Study level', 'IELTS / English test', 'Budget', 'Source', 'UTM source', 'UTM medium', 'UTM campaign', 'Status', 'Follow-up date', 'Owner', 'Notes', 'Submitted']);
    foreach ($leads as $lead) {
        fputcsv($output, [
            get_post_meta($lead->ID, '_lead_name', true) ?: $lead->post_title,
            get_post_meta($lead->ID, '_lead_phone', true), get_post_meta($lead->ID, '_lead_email', true),
            get_post_meta($lead->ID, '_lead_country', true), get_post_meta($lead->ID, '_lead_level', true),
            get_post_meta($lead->ID, '_lead_ielts', true), get_post_meta($lead->ID, '_lead_budget', true),
            get_post_meta($lead->ID, '_lead_source', true), get_post_meta($lead->ID, '_lead_utm_source', true),
            get_post_meta($lead->ID, '_lead_utm_medium', true), get_post_meta($lead->ID, '_lead_utm_campaign', true),
            get_post_meta($lead->ID, '_lead_status', true), get_post_meta($lead->ID, '_lead_follow_up_date', true),
            get_post_meta($lead->ID, '_lead_owner', true), get_post_meta($lead->ID, '_lead_notes', true),
            get_post_meta($lead->ID, '_lead_submitted_at', true) ?: $lead->post_date,
        ]);
    }
    fclose($output);
    exit;
}
add_action('admin_post_uturnedu_export_leads', 'uturnedu_export_leads_csv');

/** Main Render Dashboard Function
 */
function uturnedu_render_dashboard_page() {
    $settings = get_option('uturnedu_settings', []);
    $settings = is_array($settings) ? $settings : [];
    $homepage_content = uturnedu_get_homepage_content();

    // Default Assets
    $default_logo_primary   = get_template_directory_uri() . '/assets/images/ILMA-Education-Final1-1024x911.png';
    $default_logo_trans     = get_template_directory_uri() . '/assets/images/ILMA-Education-logo-transparent.png';
    $default_uturn_logo     = get_template_directory_uri() . '/assets/images/uturn-official-logo-transparent.png';

    $logo_primary = !empty($settings['site_logo_primary']) ? $settings['site_logo_primary'] : $default_logo_primary;
    $logo_trans   = !empty($settings['site_logo_transparent']) ? $settings['site_logo_transparent'] : $default_logo_trans;
    $address      = !empty($settings['address']) ? $settings['address'] : 'CL Tower, 772/1A, Bosila Road, Mohammadpur, Dhaka - 1207, Bangladesh';

    // Quick Counts
    $leads_count = wp_count_posts('lead')->publish ?? 0;
    $appts_count = wp_count_posts('appointment')->publish ?? 0;
    $slots_count = wp_count_posts('consult_slot')->publish ?? 0;
    $dest_count  = wp_count_posts('destination')->publish ?? 0;
    $serv_count  = wp_count_posts('service')->publish ?? 0;
    $ads_count   = wp_count_posts('ad_banner')->publish ?? 0;
    $lead_status_counts = [];
    foreach (['New' => ['New', 'new'], 'Contacted' => ['Contacted', 'contacted'], 'Qualified' => ['Qualified', 'qualified', 'interested'], 'Converted' => ['Converted', 'converted']] as $label => $values) {
        $status_query = new WP_Query([
            'post_type'      => 'lead',
            'post_status'    => 'publish',
            'posts_per_page' => 1,
            'fields'         => 'ids',
            'meta_query'     => [['key' => '_lead_status', 'value' => $values, 'compare' => 'IN']],
        ]);
        $lead_status_counts[$label] = (int) $status_query->found_posts;
        wp_reset_postdata();
    }
    $recent_lead_query = new WP_Query([
        'post_type'      => 'lead', 'post_status' => 'publish', 'posts_per_page' => 1, 'fields' => 'ids',
        'date_query'     => [['after' => gmdate('Y-m-d', strtotime('-30 days'))]],
    ]);
    $recent_leads_count = (int) $recent_lead_query->found_posts;
    wp_reset_postdata();

    // CRM filters are URL-driven so the table remains usable on large lead volumes.
    $lead_search = sanitize_text_field(wp_unslash($_GET['lead_search'] ?? ''));
    $lead_status_filter = sanitize_text_field(wp_unslash($_GET['lead_status'] ?? ''));
    $lead_source_filter = sanitize_text_field(wp_unslash($_GET['lead_source'] ?? ''));
    $lead_date_from = sanitize_text_field(wp_unslash($_GET['lead_date_from'] ?? ''));
    $lead_date_to = sanitize_text_field(wp_unslash($_GET['lead_date_to'] ?? ''));
    $lead_date_query = [];
    if ($lead_date_from !== '') {
        $lead_date_query['after'] = $lead_date_from . ' 00:00:00';
    }
    if ($lead_date_to !== '') {
        $lead_date_query['before'] = $lead_date_to . ' 23:59:59';
    }
    $lead_meta_query = [];
    if ($lead_search !== '') {
        $lead_meta_query[] = [
            'relation' => 'OR',
            ['key' => '_lead_name', 'value' => $lead_search, 'compare' => 'LIKE'],
            ['key' => '_lead_email', 'value' => $lead_search, 'compare' => 'LIKE'],
            ['key' => '_lead_phone', 'value' => $lead_search, 'compare' => 'LIKE'],
            ['key' => '_lead_country', 'value' => $lead_search, 'compare' => 'LIKE'],
        ];
    }
    if ($lead_status_filter !== '') {
        $lead_meta_query[] = ['key' => '_lead_status', 'value' => $lead_status_filter, 'compare' => '='];
    }
    if ($lead_source_filter !== '') {
        $lead_meta_query[] = ['key' => '_lead_source', 'value' => $lead_source_filter, 'compare' => 'LIKE'];
    }
    $recent_leads = get_posts([
        'post_type'      => 'lead',
        'posts_per_page' => 100,
        'post_status'    => 'publish',
        'orderby'        => 'date',
        'order'          => 'DESC',
        'meta_query'     => $lead_meta_query,
        'date_query'     => $lead_date_query,
    ]);

    $recent_appts = get_posts([
        'post_type'      => 'appointment',
        'posts_per_page' => 20,
        'post_status'    => 'publish',
        'orderby'        => 'date',
        'order'          => 'DESC'
    ]);

    $slots = get_posts([
        'post_type'      => 'consult_slot',
        'posts_per_page' => -1,
        'post_status'    => 'publish',
        'orderby'        => 'title',
        'order'          => 'ASC'
    ]);

    $ads = get_posts([
        'post_type'      => 'ad_banner',
        'posts_per_page' => -1,
        'post_status'    => 'publish',
    ]);
    $managed_pages = get_posts([
        'post_type'      => 'page',
        'posts_per_page' => -1,
        'post_status'    => ['publish', 'draft', 'pending', 'private'],
        'orderby'        => 'menu_order title',
        'order'          => 'ASC',
    ]);
    $managed_destinations = get_posts([
        'post_type'      => 'destination',
        'posts_per_page' => -1,
        'post_status'    => ['publish', 'draft', 'pending', 'private'],
        'orderby'        => 'menu_order title',
        'order'          => 'ASC',
    ]);
    $managed_services = get_posts([
        'post_type'      => 'service',
        'posts_per_page' => -1,
        'post_status'    => ['publish', 'draft', 'pending', 'private'],
        'orderby'        => 'menu_order title',
        'order'          => 'ASC',
    ]);
    $managed_testimonials = get_posts([
        'post_type'      => 'testimonial',
        'posts_per_page' => -1,
        'post_status'    => ['publish', 'draft', 'pending', 'private'],
        'orderby'        => 'date',
        'order'          => 'DESC',
    ]);
    $managed_counselors = get_posts([
        'post_type'      => 'counselor',
        'posts_per_page' => -1,
        'post_status'    => ['publish', 'draft', 'pending', 'private'],
        'orderby'        => 'menu_order title',
        'order'          => 'ASC',
    ]);
    ?>
    <div class="wrap uturnedu-dashboard-wrap">
        <?php if (isset($_GET['updated'])): ?>
            <div class="uturnedu-alert uturnedu-alert-success">
                <span>✓</span> <strong>Settings saved successfully!</strong> All front-end templates, headers, footers, popups, and office details have been updated sitewide.
            </div>
        <?php endif; ?>
        <?php if (isset($_GET['reinstalled'])): ?>
            <div class="uturnedu-alert uturnedu-alert-info">
                <span>🔄</span> <strong>Starter Content Re-synchronized!</strong> Default study destinations, services, and appointment slots are active.
            </div>
        <?php endif; ?>

        <!-- Agency dashboard header -->
        <div class="uturnedu-dash-header">
            <div class="uturnedu-dash-brand">
                <div class="uturnedu-logo-badge">
                    <img src="<?php echo esc_url($logo_primary); ?>" alt="ILMA Education Consultancy" style="height: 42px; width: auto; object-fit: contain;">
                </div>
                <div>
                    <div class="uturnedu-dash-title-row">
                        <h1 class="uturnedu-dash-title">ILMA Education Consultancy</h1>
                        <span class="uturnedu-pill uturnedu-pill-accent">Admin workspace</span>
                    </div>
                    <p class="uturnedu-dash-sub">
                        Website control centre <span aria-hidden="true">•</span> <?php echo esc_html($settings['office_area'] ?? 'Mohammadpur, Dhaka'); ?> <span aria-hidden="true">•</span> Manage content, media and student enquiries
                    </p>
                </div>
            </div>
            <div class="uturnedu-dash-actions">
                <a href="<?php echo esc_url(home_url('/')); ?>" target="_blank" rel="noopener" class="uturnedu-btn uturnedu-btn-light">🌐 View live site <span aria-hidden="true">↗</span></a>
            </div>
        </div>

        <div class="uturnedu-dashboard-layout">
          <!-- Workspace navigation -->
          <aside class="uturnedu-nav-tabs" aria-label="Agency dashboard sections">
            <div class="uturnedu-nav-heading"><span class="uturnedu-section-eyebrow">Workspace</span><strong>Manage ILMA</strong></div>
            <button type="button" class="uturnedu-tab-btn active" data-tab="tab-overview"><span class="uturnedu-nav-icon">⌂</span><span>Overview</span></button>
            <button type="button" class="uturnedu-tab-btn" data-tab="tab-content"><span class="uturnedu-nav-icon">✦</span><span>Content Studio</span></button>
            <button type="button" class="uturnedu-tab-btn" data-tab="tab-builder"><span class="uturnedu-nav-icon">◈</span><span>Homepage Builder</span></button>
            <div class="uturnedu-nav-divider"><span>Student operations</span></div>
            <button type="button" class="uturnedu-tab-btn" data-tab="tab-leads"><span class="uturnedu-nav-icon">♧</span><span>Leads CRM</span><span class="uturnedu-counter"><?php echo esc_html($leads_count); ?></span></button>
            <button type="button" class="uturnedu-tab-btn" data-tab="tab-forms"><span class="uturnedu-nav-icon">▣</span><span>Forms &amp; submissions</span></button>
            <button type="button" class="uturnedu-tab-btn" data-tab="tab-appointments"><span class="uturnedu-nav-icon">◷</span><span>Bookings</span><span class="uturnedu-counter"><?php echo esc_html($appts_count); ?></span></button>
            <button type="button" class="uturnedu-tab-btn" data-tab="tab-slots"><span class="uturnedu-nav-icon">⌚</span><span>Availability</span></button>
            <div class="uturnedu-nav-divider"><span>Marketing</span></div>
            <button type="button" class="uturnedu-tab-btn" data-tab="tab-popup"><span class="uturnedu-nav-icon">◎</span><span>Popup Campaign</span></button>
            <button type="button" class="uturnedu-tab-btn" data-tab="tab-ads"><span class="uturnedu-nav-icon">▱</span><span>Ad Banners</span></button>
            <button type="button" class="uturnedu-tab-btn" data-tab="tab-settings"><span class="uturnedu-nav-icon">⚙</span><span>Agency Settings</span></button>
            <div class="uturnedu-nav-help"><strong>Need to publish?</strong><span>Use Content Studio to edit pages, destinations, services and media.</span></div>
          </aside>
          <main class="uturnedu-dashboard-main">

        <!-- ==========================================
             1. TAB: OVERVIEW
             ========================================== -->
        <div id="tab-overview" class="uturnedu-tab-pane active">
            <div class="uturnedu-grid-4">
                <div class="uturnedu-card uturnedu-stat-card">
                    <div class="uturnedu-stat-icon" style="background: rgba(37, 99, 235, 0.1); color: #2563EB;">📥</div>
                    <div class="uturnedu-stat-num"><?php echo esc_html($leads_count); ?></div>
                    <div class="uturnedu-stat-label">Total Student Inquiries</div>
                    <div class="uturnedu-stat-meta" style="color: #059669;">Live counselling requests</div>
                </div>

                <div class="uturnedu-card uturnedu-stat-card">
                    <div class="uturnedu-stat-icon" style="background: rgba(220, 38, 38, 0.1); color: #DC2626;">📅</div>
                    <div class="uturnedu-stat-num" style="color: #DC2626;"><?php echo esc_html($appts_count); ?></div>
                    <div class="uturnedu-stat-label">Office Appointments</div>
                    <div class="uturnedu-stat-meta">In-Person at Mohammadpur Office</div>
                </div>

                <div class="uturnedu-card uturnedu-stat-card">
                    <div class="uturnedu-stat-icon" style="background: rgba(5, 150, 105, 0.1); color: #059669;">🌍</div>
                    <div class="uturnedu-stat-num" style="color: #059669;"><?php echo esc_html($dest_count); ?></div>
                    <div class="uturnedu-stat-label">Destinations Active</div>
                    <div class="uturnedu-stat-meta">United Kingdom, New Zealand, Canada, Malaysia, South Korea &amp; Japan</div>
                </div>

                <div class="uturnedu-card uturnedu-stat-card">
                    <div class="uturnedu-stat-icon" style="background: rgba(217, 119, 6, 0.1); color: #D97706;">🎯</div>
                    <div class="uturnedu-stat-num" style="color: #D97706;"><?php echo ($settings['popup_enabled'] ?? 'yes') === 'yes' ? 'Active' : 'Off'; ?></div>
                    <div class="uturnedu-stat-label">Popup Campaign Mode</div>
                    <div class="uturnedu-stat-meta"><?php echo ucfirst(str_replace('_', ' ', $settings['popup_type'] ?? 'Image & Text')); ?></div>
                </div>
            </div>

            <div class="uturnedu-dashboard-stat-strip" aria-label="Lead statistics">
                <div><span>New</span><strong><?php echo esc_html($lead_status_counts['New']); ?></strong><small>Needs first response</small></div>
                <div><span>Contacted</span><strong><?php echo esc_html($lead_status_counts['Contacted']); ?></strong><small>In conversation</small></div>
                <div><span>Qualified</span><strong><?php echo esc_html($lead_status_counts['Qualified']); ?></strong><small>Profile reviewed</small></div>
                <div><span>Converted</span><strong><?php echo esc_html($lead_status_counts['Converted']); ?></strong><small>Marked converted</small></div>
                <div><span>Last 30 days</span><strong><?php echo esc_html($recent_leads_count); ?></strong><small>New submissions</small></div>
            </div>

            <!-- Quick Action Shortcuts -->
            <div class="uturnedu-card" style="margin-top: 24px;">
                <h3 style="margin: 0 0 16px 0; font-size: 16px; font-weight: 700;">🚀 Quick Management Controls</h3>
                <div style="display: flex; gap: 12px; flex-wrap: wrap;">
                    <button type="button" class="uturnedu-btn uturnedu-btn-primary" onclick="document.querySelector('[data-tab=\'tab-leads\']').click();">
                        📥 View All Leads CRM
                    </button>
                    <button type="button" class="uturnedu-btn uturnedu-btn-outline" onclick="document.querySelector('[data-tab=\'tab-appointments\']').click();">
                        📅 Check Office Bookings
                    </button>
                    <button type="button" class="uturnedu-btn uturnedu-btn-outline" onclick="document.querySelector('[data-tab=\'tab-popup\']').click();">
                        🎯 Configure Popup (Image/Text)
                    </button>
                    <button type="button" class="uturnedu-btn uturnedu-btn-outline" onclick="document.querySelector('[data-tab=\'tab-settings\']').click();">
                        🏢 Update Office Address & Logos
                    </button>
                </div>
            </div>
        </div>

        <!-- ==========================================
             2. TAB: CONTENT STUDIO
             ========================================== -->
        <div id="tab-content" class="uturnedu-tab-pane">
            <section class="uturnedu-content-hero">
                <div>
                    <span class="uturnedu-section-eyebrow">Your publishing workspace</span>
                    <h2>Everything your students see, in one place.</h2>
                    <p>Edit page copy, destination guides, service pages, images, menus and campaign media without touching theme files. Use <strong>Homepage Builder</strong> for the homepage sections and <strong>Content Studio</strong> for the rest of the website.</p>
                </div>
                <div class="uturnedu-content-hero-actions">
                    <input type="search" class="uturnedu-content-search" data-content-search placeholder="Search content" aria-label="Search content">
                    <a class="uturnedu-btn uturnedu-btn-primary" href="<?php echo esc_url(admin_url('post-new.php?post_type=page')); ?>">＋ Add new page</a>
                    <a class="uturnedu-btn uturnedu-btn-outline" href="<?php echo esc_url(admin_url('upload.php')); ?>">＋ Upload media</a>
                </div>
            </section>

            <div class="uturnedu-content-metrics">
                <button type="button" class="uturnedu-mini-stat" data-content-filter="pages"><span class="uturnedu-mini-stat-icon">▤</span><span><strong><?php echo esc_html(count($managed_pages)); ?></strong><small>Pages to manage</small></span></button>
                <button type="button" class="uturnedu-mini-stat" data-content-filter="destinations"><span class="uturnedu-mini-stat-icon">◎</span><span><strong><?php echo esc_html(count($managed_destinations)); ?></strong><small>Destination guides</small></span></button>
                <button type="button" class="uturnedu-mini-stat" data-content-filter="services"><span class="uturnedu-mini-stat-icon">✦</span><span><strong><?php echo esc_html(count($managed_services)); ?></strong><small>Service pages</small></span></button>
                <a class="uturnedu-mini-stat" href="<?php echo esc_url(admin_url('upload.php')); ?>"><span class="uturnedu-mini-stat-icon">▧</span><span><strong>Media</strong><small>Images &amp; files</small></span></a>
            </div>

            <div class="uturnedu-content-grid">
                <section class="uturnedu-card uturnedu-library-card" data-content-library="pages">
                    <div class="uturnedu-library-heading"><div><span class="uturnedu-section-eyebrow">Page library</span><h3>Pages &amp; landing screens</h3><p>Edit titles, page copy, SEO fields, featured images and templates from the familiar WordPress editor.</p></div><a class="uturnedu-btn uturnedu-btn-outline uturnedu-btn-sm" href="<?php echo esc_url(admin_url('edit.php?post_type=page')); ?>">Open full list ↗</a></div>
                    <div class="uturnedu-page-list">
                        <?php if (!empty($managed_pages)): foreach ($managed_pages as $page):
                            $page_status = get_post_status_object($page->post_status);
                            $page_template = get_page_template_slug($page->ID);
                            $page_url = get_permalink($page->ID);
                            $delete_url = get_delete_post_link($page->ID);
                        ?>
                            <article class="uturnedu-page-row">
                                <span class="uturnedu-content-type-icon">▤</span>
                                <div class="uturnedu-page-row-main"><strong><?php echo esc_html($page->post_title); ?></strong><span><?php echo esc_html($page->post_name ? '/' . $page->post_name . '/' : 'No slug'); ?><?php if ($page_template): ?> <em><?php echo esc_html(str_replace('page-', '', str_replace('.php', '', $page_template))); ?></em><?php endif; ?></span></div>
                                <span class="uturnedu-status-dot <?php echo $page->post_status === 'publish' ? 'is-live' : 'is-draft'; ?>"><?php echo esc_html($page_status ? $page_status->label : ucfirst($page->post_status)); ?></span>
                                <div class="uturnedu-row-actions"><a href="<?php echo esc_url(get_edit_post_link($page->ID)); ?>">Edit</a><?php if ($page_url): ?><a href="<?php echo esc_url($page_url); ?>" target="_blank" rel="noopener">View</a><?php endif; ?><?php if ($delete_url): ?><a class="is-danger" href="<?php echo esc_url($delete_url); ?>" onclick="return confirm('Move this page to the trash?');">Remove</a><?php endif; ?></div>
                            </article>
                        <?php endforeach; else: ?><div class="uturnedu-empty-content">No pages found. Create the first page above.</div><?php endif; ?>
                    </div>
                </section>

                <aside class="uturnedu-card uturnedu-publishing-card">
                    <span class="uturnedu-section-eyebrow">Simple publishing flow</span>
                    <h3>Make a change safely</h3>
                    <ol class="uturnedu-publishing-steps"><li><b>1</b><span>Choose a page or content type.</span></li><li><b>2</b><span>Edit copy and choose images.</span></li><li><b>3</b><span>Preview the live page.</span></li><li><b>4</b><span>Publish when everything looks right.</span></li></ol>
                    <div class="uturnedu-publishing-tip"><strong>Tip</strong><span>Use the Media Library to reuse the same approved logo, banner or destination image anywhere on the site.</span></div>
                    <a class="uturnedu-text-action" href="<?php echo esc_url(admin_url('nav-menus.php')); ?>">Manage navigation menus <span aria-hidden="true">→</span></a>
                </aside>
            </div>

            <section class="uturnedu-card uturnedu-library-card" data-content-library="destinations">
                <div class="uturnedu-library-heading"><div><span class="uturnedu-section-eyebrow">Destination library</span><h3>Hero slides, destination cards &amp; guides</h3><p>Each destination controls its public card, hero slide, guide copy, facts and image from one editor.</p></div><div class="uturnedu-library-actions"><a class="uturnedu-btn uturnedu-btn-primary uturnedu-btn-sm" href="<?php echo esc_url(admin_url('post-new.php?post_type=destination')); ?>">＋ Add destination</a><a class="uturnedu-btn uturnedu-btn-outline uturnedu-btn-sm" href="<?php echo esc_url(admin_url('edit.php?post_type=destination')); ?>">View all</a></div></div>
                <div class="uturnedu-content-item-grid">
                    <?php if (!empty($managed_destinations)): foreach ($managed_destinations as $destination):
                        $destination_code = get_post_meta($destination->ID, '_dest_code', true) ?: $destination->post_name;
                        $destination_image = uturnedu_get_destination_image($destination_code);
                        $destination_url = get_permalink($destination->ID);
                        $destination_delete_url = get_delete_post_link($destination->ID);
                    ?>
                        <article class="uturnedu-content-item-card"><div class="uturnedu-content-item-image"><img src="<?php echo esc_url($destination_image); ?>" alt="" loading="lazy"><span class="uturnedu-content-item-badge">Destination</span></div><div class="uturnedu-content-item-body"><strong><?php echo esc_html($destination->post_title); ?></strong><span><?php echo esc_html($destination->post_status === 'publish' ? 'Live on website' : ucfirst($destination->post_status)); ?></span><div class="uturnedu-row-actions"><a href="<?php echo esc_url(get_edit_post_link($destination->ID)); ?>">Edit guide &amp; image</a><?php if ($destination_url): ?><a href="<?php echo esc_url($destination_url); ?>" target="_blank" rel="noopener">View ↗</a><?php endif; ?><?php if ($destination_delete_url): ?><a class="is-danger" href="<?php echo esc_url($destination_delete_url); ?>" onclick="return confirm('Move this destination to the trash?');">Remove</a><?php endif; ?></div></div></article>
                    <?php endforeach; else: ?><div class="uturnedu-empty-content">No destinations found. Add one to create a new guide and hero card.</div><?php endif; ?>
                </div>
            </section>

            <section class="uturnedu-card uturnedu-library-card" data-content-library="services">
                <div class="uturnedu-library-heading"><div><span class="uturnedu-section-eyebrow">Service library</span><h3>Services and process pages</h3><p>Keep your service descriptions, process steps, badges and featured images current.</p></div><div class="uturnedu-library-actions"><a class="uturnedu-btn uturnedu-btn-primary uturnedu-btn-sm" href="<?php echo esc_url(admin_url('post-new.php?post_type=service')); ?>">＋ Add service</a><a class="uturnedu-btn uturnedu-btn-outline uturnedu-btn-sm" href="<?php echo esc_url(admin_url('edit.php?post_type=service')); ?>">View all</a></div></div>
                <div class="uturnedu-service-list">
                    <?php if (!empty($managed_services)): foreach ($managed_services as $service): $service_delete_url = get_delete_post_link($service->ID); ?><article class="uturnedu-service-row"><span class="uturnedu-content-type-icon is-service">✦</span><div class="uturnedu-page-row-main"><strong><?php echo esc_html($service->post_title); ?></strong><span><?php echo esc_html($service->post_status === 'publish' ? 'Published service page' : ucfirst($service->post_status)); ?></span></div><div class="uturnedu-row-actions"><a href="<?php echo esc_url(get_edit_post_link($service->ID)); ?>">Edit service</a><?php if (get_permalink($service->ID)): ?><a href="<?php echo esc_url(get_permalink($service->ID)); ?>" target="_blank" rel="noopener">View ↗</a><?php endif; ?><?php if ($service_delete_url): ?><a class="is-danger" href="<?php echo esc_url($service_delete_url); ?>" onclick="return confirm('Move this service to the trash?');">Remove</a><?php endif; ?></div></article><?php endforeach; else: ?><div class="uturnedu-empty-content">No services found. Add a service page above.</div><?php endif; ?>
                </div>
            </section>

            <section class="uturnedu-card uturnedu-library-card" data-content-library="people">
                <div class="uturnedu-library-heading"><div><span class="uturnedu-section-eyebrow">People &amp; proof</span><h3>Testimonials and counselors</h3><p>Keep real student perspectives and counselor profiles current. Use the WordPress editor to update copy, details and featured images.</p></div><div class="uturnedu-library-actions"><a class="uturnedu-btn uturnedu-btn-primary uturnedu-btn-sm" href="<?php echo esc_url(admin_url('post-new.php?post_type=testimonial')); ?>">＋ Add testimonial</a><a class="uturnedu-btn uturnedu-btn-outline uturnedu-btn-sm" href="<?php echo esc_url(admin_url('post-new.php?post_type=counselor')); ?>">＋ Add counselor</a></div></div>
                <div class="uturnedu-people-grid">
                    <div><div class="uturnedu-sub-library-heading"><strong>Student perspectives</strong><a href="<?php echo esc_url(admin_url('edit.php?post_type=testimonial')); ?>">View all</a></div><?php if (!empty($managed_testimonials)): foreach ($managed_testimonials as $testimonial): $testimonial_delete_url = get_delete_post_link($testimonial->ID); ?><article class="uturnedu-person-row"><span class="uturnedu-content-type-icon">❝</span><div class="uturnedu-page-row-main"><strong><?php echo esc_html($testimonial->post_title); ?></strong><span><?php echo esc_html($testimonial->post_status === 'publish' ? 'Published testimonial' : ucfirst($testimonial->post_status)); ?></span></div><div class="uturnedu-row-actions"><a href="<?php echo esc_url(get_edit_post_link($testimonial->ID)); ?>">Edit</a><?php if (get_permalink($testimonial->ID)): ?><a href="<?php echo esc_url(get_permalink($testimonial->ID)); ?>" target="_blank" rel="noopener">View ↗</a><?php endif; ?><?php if ($testimonial_delete_url): ?><a class="is-danger" href="<?php echo esc_url($testimonial_delete_url); ?>" onclick="return confirm('Move this testimonial to the trash?');">Remove</a><?php endif; ?></div></article><?php endforeach; else: ?><div class="uturnedu-empty-content">No testimonials yet.</div><?php endif; ?></div>
                    <div><div class="uturnedu-sub-library-heading"><strong>Our counselors</strong><a href="<?php echo esc_url(admin_url('edit.php?post_type=counselor')); ?>">View all</a></div><?php if (!empty($managed_counselors)): foreach ($managed_counselors as $counselor): $counselor_delete_url = get_delete_post_link($counselor->ID); ?><article class="uturnedu-person-row"><span class="uturnedu-content-type-icon is-service">♙</span><div class="uturnedu-page-row-main"><strong><?php echo esc_html($counselor->post_title); ?></strong><span><?php echo esc_html($counselor->post_status === 'publish' ? 'Published profile' : ucfirst($counselor->post_status)); ?></span></div><div class="uturnedu-row-actions"><a href="<?php echo esc_url(get_edit_post_link($counselor->ID)); ?>">Edit</a><?php if ($counselor_delete_url): ?><a class="is-danger" href="<?php echo esc_url($counselor_delete_url); ?>" onclick="return confirm('Move this counselor profile to the trash?');">Remove</a><?php endif; ?></div></article><?php endforeach; else: ?><div class="uturnedu-empty-content">No counselor profiles yet.</div><?php endif; ?></div>
                </div>
            </section>
        </div>

        <!-- ==========================================
             3. TAB: SITE BUILDER
             ========================================== -->
        <div id="tab-builder" class="uturnedu-tab-pane">
            <form method="post" class="uturnedu-card uturnedu-builder-form">
                <?php wp_nonce_field('uturnedu_save_homepage_content', 'uturnedu_homepage_nonce'); ?>
                <div class="uturnedu-builder-intro">
                    <div><span class="uturnedu-section-eyebrow">No-code content controls</span><h2>Homepage Site Builder</h2><p>Edit the homepage copy, calls to action and optional video without touching theme files. Destination and service cards are managed from the <strong>Destinations</strong> and <strong>Services</strong> menus, including their descriptions, images and details.</p></div>
                    <a class="uturnedu-btn uturnedu-btn-light" href="<?php echo esc_url(home_url('/')); ?>" target="_blank" rel="noopener">Preview homepage ↗</a>
                </div>
                <div class="uturnedu-builder-grid">
                    <fieldset><legend>Hero & destination section</legend>
                        <label class="uturnedu-label">Hero eyebrow<input class="uturnedu-input" name="hero_kicker" value="<?php echo esc_attr($homepage_content['hero_kicker']); ?>"></label>
                        <label class="uturnedu-label">Primary CTA label<input class="uturnedu-input" name="hero_cta" value="<?php echo esc_attr($homepage_content['hero_cta']); ?>"></label>
                        <label class="uturnedu-label">Secondary CTA label<input class="uturnedu-input" name="hero_secondary_cta" value="<?php echo esc_attr($homepage_content['hero_secondary_cta']); ?>"></label>
                        <label class="uturnedu-label">Destination eyebrow<input class="uturnedu-input" name="destination_kicker" value="<?php echo esc_attr($homepage_content['destination_kicker']); ?>"></label>
                        <label class="uturnedu-label">Destination heading<input class="uturnedu-input" name="destination_title" value="<?php echo esc_attr($homepage_content['destination_title']); ?>"></label>
                        <label class="uturnedu-label">Destination introduction<textarea class="uturnedu-textarea" name="destination_intro" rows="3"><?php echo esc_textarea($homepage_content['destination_intro']); ?></textarea></label>
                    </fieldset>
                    <fieldset><legend>Why us & services</legend>
                        <label class="uturnedu-label">Why us eyebrow<input class="uturnedu-input" name="why_kicker" value="<?php echo esc_attr($homepage_content['why_kicker']); ?>"></label>
                        <label class="uturnedu-label">Why us heading<input class="uturnedu-input" name="why_title" value="<?php echo esc_attr($homepage_content['why_title']); ?>"></label>
                        <label class="uturnedu-label">Why us introduction<textarea class="uturnedu-textarea" name="why_intro" rows="3"><?php echo esc_textarea($homepage_content['why_intro']); ?></textarea></label>
                        <?php for ($card = 1; $card <= 4; $card++): ?><label class="uturnedu-label">Why card <?php echo $card; ?> heading<input class="uturnedu-input" name="why_card_<?php echo $card; ?>_title" value="<?php echo esc_attr($homepage_content['why_card_'.$card.'_title']); ?>"></label><label class="uturnedu-label">Why card <?php echo $card; ?> copy<textarea class="uturnedu-textarea" name="why_card_<?php echo $card; ?>_text" rows="2"><?php echo esc_textarea($homepage_content['why_card_'.$card.'_text']); ?></textarea></label><?php endfor; ?>
                        <label class="uturnedu-label">Services eyebrow<input class="uturnedu-input" name="services_kicker" value="<?php echo esc_attr($homepage_content['services_kicker']); ?>"></label>
                        <label class="uturnedu-label">Services heading<input class="uturnedu-input" name="services_title" value="<?php echo esc_attr($homepage_content['services_title']); ?>"></label>
                        <label class="uturnedu-label">Services introduction<textarea class="uturnedu-textarea" name="services_intro" rows="3"><?php echo esc_textarea($homepage_content['services_intro']); ?></textarea></label>
                    </fieldset>
                    <fieldset><legend>Process & conversion</legend>
                        <label class="uturnedu-label">Process eyebrow<input class="uturnedu-input" name="process_kicker" value="<?php echo esc_attr($homepage_content['process_kicker']); ?>"></label>
                        <label class="uturnedu-label">Process heading<input class="uturnedu-input" name="process_title" value="<?php echo esc_attr($homepage_content['process_title']); ?>"></label>
                        <label class="uturnedu-label">Process introduction<textarea class="uturnedu-textarea" name="process_intro" rows="3"><?php echo esc_textarea($homepage_content['process_intro']); ?></textarea></label>
                        <?php for ($step = 1; $step <= 4; $step++): ?><label class="uturnedu-label">Process step <?php echo $step; ?> heading<input class="uturnedu-input" name="process_<?php echo $step; ?>_title" value="<?php echo esc_attr($homepage_content['process_'.$step.'_title']); ?>"></label><label class="uturnedu-label">Process step <?php echo $step; ?> copy<textarea class="uturnedu-textarea" name="process_<?php echo $step; ?>_text" rows="2"><?php echo esc_textarea($homepage_content['process_'.$step.'_text']); ?></textarea></label><?php endfor; ?>
                        <label class="uturnedu-label">Eligibility eyebrow<input class="uturnedu-input" name="eligibility_kicker" value="<?php echo esc_attr($homepage_content['eligibility_kicker']); ?>"></label>
                        <label class="uturnedu-label">Eligibility heading<input class="uturnedu-input" name="eligibility_title" value="<?php echo esc_attr($homepage_content['eligibility_title']); ?>"></label>
                        <label class="uturnedu-label">Eligibility copy<textarea class="uturnedu-textarea" name="eligibility_text" rows="3"><?php echo esc_textarea($homepage_content['eligibility_text']); ?></textarea></label>
                        <label class="uturnedu-label">Eligibility CTA<input class="uturnedu-input" name="eligibility_cta" value="<?php echo esc_attr($homepage_content['eligibility_cta']); ?>"></label>
                    </fieldset>
                    <fieldset><legend>Contact section & media</legend>
                        <label class="uturnedu-label">Contact eyebrow<input class="uturnedu-input" name="contact_kicker" value="<?php echo esc_attr($homepage_content['contact_kicker']); ?>"></label>
                        <label class="uturnedu-label">Contact heading<input class="uturnedu-input" name="contact_title" value="<?php echo esc_attr($homepage_content['contact_title']); ?>"></label>
                        <label class="uturnedu-label">Contact copy<textarea class="uturnedu-textarea" name="contact_text" rows="3"><?php echo esc_textarea($homepage_content['contact_text']); ?></textarea></label>
                        <label class="uturnedu-label">Show homepage video<select class="uturnedu-select" name="video_enabled"><option value="no" <?php selected($homepage_content['video_enabled'], 'no'); ?>>No</option><option value="yes" <?php selected($homepage_content['video_enabled'], 'yes'); ?>>Yes</option></select></label>
                        <label class="uturnedu-label">Video URL<input type="url" class="uturnedu-input" name="video_url" value="<?php echo esc_url($homepage_content['video_url']); ?>" placeholder="YouTube, Vimeo or MP4 URL"></label>
                        <label class="uturnedu-label">Video poster image
                            <div class="uturnedu-media-row"><input type="url" id="uturnedu-video-poster" class="uturnedu-input" name="video_poster" value="<?php echo esc_url($homepage_content['video_poster']); ?>"><button type="button" class="uturnedu-media-button" data-media-target="uturnedu-video-poster">Choose image</button></div>
                        </label>
                        <label class="uturnedu-label">Video heading<input class="uturnedu-input" name="video_title" value="<?php echo esc_attr($homepage_content['video_title']); ?>"></label>
                        <label class="uturnedu-label">Video supporting copy<textarea class="uturnedu-textarea" name="video_text" rows="2"><?php echo esc_textarea($homepage_content['video_text']); ?></textarea></label>
                    </fieldset>
                </div>
                <p><button type="submit" class="uturnedu-btn uturnedu-btn-primary">Save homepage changes</button></p>
            </form>
            <div class="uturnedu-card uturnedu-builder-links"><h3>Manage the rest of the website</h3><div class="uturnedu-builder-link-grid"><a href="edit.php?post_type=destination">🌍 Destinations & hero images</a><a href="edit.php?post_type=service">🧭 Services & service pages</a><a href="edit.php?post_type=testimonial">💬 Student perspectives</a><a href="nav-menus.php">🧩 Menus & navigation</a><a href="upload.php">🖼️ Media library</a><a href="edit.php?post_type=page">📄 Pages & SEO copy</a></div></div>
        </div>

        <!-- ==========================================
             3. TAB: LEADS CRM
             ========================================== -->
        <div id="tab-leads" class="uturnedu-tab-pane">
            <div class="uturnedu-card">
                <div class="uturnedu-crm-heading">
                    <div><h2>Student Leads CRM</h2><p>Search, prioritise, assign and update every enquiry from one workspace. Changes save without leaving this dashboard.</p></div>
                    <a class="uturnedu-btn uturnedu-btn-outline" href="<?php echo esc_url(wp_nonce_url(admin_url('admin-post.php?action=uturnedu_export_leads'), 'uturnedu_export_leads')); ?>">Download CSV</a>
                </div>
                <form method="get" class="uturnedu-crm-filters">
                    <input type="hidden" name="page" value="uturnedu_dashboard"><input type="hidden" name="tab" value="leads">
                    <input class="uturnedu-input" type="search" name="lead_search" value="<?php echo esc_attr($lead_search); ?>" placeholder="Search name, phone, email or country">
                    <select class="uturnedu-select" name="lead_status"><option value="">All statuses</option><?php foreach (['New','Contacted','Qualified','Follow-up','Applied','Converted','Closed'] as $filter_status): ?><option value="<?php echo esc_attr($filter_status); ?>" <?php selected($lead_status_filter, $filter_status); ?>><?php echo esc_html($filter_status); ?></option><?php endforeach; ?></select>
                    <input class="uturnedu-input" type="search" name="lead_source" value="<?php echo esc_attr($lead_source_filter); ?>" placeholder="Source, e.g. Meta Ads">
                    <label class="uturnedu-filter-date">From <input class="uturnedu-input" type="date" name="lead_date_from" value="<?php echo esc_attr($lead_date_from); ?>"></label>
                    <label class="uturnedu-filter-date">To <input class="uturnedu-input" type="date" name="lead_date_to" value="<?php echo esc_attr($lead_date_to); ?>"></label>
                    <button class="uturnedu-btn uturnedu-btn-primary" type="submit">Filter leads</button>
                    <a class="uturnedu-btn uturnedu-btn-light" href="<?php echo esc_url(admin_url('admin.php?page=uturnedu_dashboard&tab=leads')); ?>">Reset</a>
                </form>
                <p class="uturnedu-crm-result-count"><strong><?php echo esc_html(count($recent_leads)); ?></strong> lead records shown · Latest 100 records maximum</p>
                <div class="uturnedu-table-responsive">
                    <table class="uturnedu-table uturnedu-crm-table">
                        <thead><tr><th>Student</th><th>Contact</th><th>Interest</th><th>Source / campaign</th><th>Received</th><th>Follow-up</th><th>Owner & notes</th><th>Status</th></tr></thead>
                        <tbody>
                        <?php if (!empty($recent_leads)): foreach ($recent_leads as $lead):
                            $phone = get_post_meta($lead->ID, '_lead_phone', true); $email = get_post_meta($lead->ID, '_lead_email', true); $country = get_post_meta($lead->ID, '_lead_country', true);
                            $level = get_post_meta($lead->ID, '_lead_level', true) ?: get_post_meta($lead->ID, '_lead_study_level', true); $source = get_post_meta($lead->ID, '_lead_source', true) ?: 'Website';
                            $status = get_post_meta($lead->ID, '_lead_status', true) ?: 'New'; $status = ['new' => 'New', 'contacted' => 'Contacted', 'interested' => 'Qualified', 'converted' => 'Converted', 'closed' => 'Closed'][$status] ?? $status; $follow_date = get_post_meta($lead->ID, '_lead_follow_up_date', true); $follow_note = get_post_meta($lead->ID, '_lead_follow_up_note', true);
                            $owner = get_post_meta($lead->ID, '_lead_owner', true); $notes = get_post_meta($lead->ID, '_lead_notes', true); $clean_phone = preg_replace('/[^0-9]/', '', $phone); $lead_delete_url = get_delete_post_link($lead->ID);
                            $status_class = in_array($status, ['Converted','Applied'], true) ? 'uturnedu-badge-confirmed' : ($status === 'Closed' ? 'uturnedu-badge-cancelled' : ($status === 'Contacted' || $status === 'Qualified' ? 'uturnedu-badge-blue' : 'uturnedu-badge-pending'));
                        ?>
                            <tr data-lead-row="<?php echo esc_attr($lead->ID); ?>">
                                <td><strong><?php echo esc_html(get_post_meta($lead->ID, '_lead_name', true) ?: $lead->post_title); ?></strong><small><?php echo esc_html($level ?: 'Study enquiry'); ?></small><button type="button" class="uturnedu-view-lead" data-lead-name="<?php echo esc_attr(get_post_meta($lead->ID, '_lead_name', true) ?: $lead->post_title); ?>" data-lead-phone="<?php echo esc_attr($phone); ?>" data-lead-email="<?php echo esc_attr($email); ?>" data-lead-country="<?php echo esc_attr($country); ?>" data-lead-source="<?php echo esc_attr($source); ?>" data-lead-received="<?php echo esc_attr(get_the_date('M j, Y g:i a', $lead->ID)); ?>" data-lead-status="<?php echo esc_attr($status); ?>" data-lead-message="<?php echo esc_attr($notes); ?>">View details</button></td>
                                <td><a href="tel:<?php echo esc_attr($phone); ?>"><?php echo esc_html($phone ?: '—'); ?></a><?php if ($clean_phone): ?><a href="https://wa.me/<?php echo esc_attr($clean_phone); ?>" target="_blank" rel="noopener" title="Chat with Us" class="uturnedu-crm-whatsapp">Chat with Us</a><?php endif; ?><a href="mailto:<?php echo esc_attr($email); ?>"><?php echo esc_html($email ?: '—'); ?></a></td>
                                <td><span class="uturnedu-badge uturnedu-badge-blue"><?php echo esc_html($country ?: 'General'); ?></span><small><?php echo esc_html(get_post_meta($lead->ID, '_lead_target_intake', true) ?: 'Intake not set'); ?></small></td>
                                <td><strong><?php echo esc_html($source); ?></strong><?php $campaign = get_post_meta($lead->ID, '_lead_utm_campaign', true); if ($campaign): ?><small>Campaign: <?php echo esc_html($campaign); ?></small><?php endif; ?></td>
                                <td style="font-size:12px;color:#64748B;"><?php echo esc_html(get_the_date('M j, Y', $lead->ID)); ?></td>
                                <td><input class="uturnedu-crm-date" type="date" value="<?php echo esc_attr($follow_date); ?>" data-lead-field="follow_up_date" aria-label="Follow-up date"><small><?php echo esc_html($follow_note); ?></small></td>
                                <td><input class="uturnedu-crm-owner" type="text" value="<?php echo esc_attr($owner); ?>" data-lead-field="owner" placeholder="Assign owner" aria-label="Lead owner"><textarea class="uturnedu-crm-note" data-lead-field="notes" rows="2" placeholder="Notes"><?php echo esc_textarea($notes); ?></textarea><button type="button" class="uturnedu-btn uturnedu-btn-light uturnedu-save-lead" data-lead-id="<?php echo esc_attr($lead->ID); ?>">Save</button><?php if ($lead_delete_url): ?><a class="uturnedu-crm-delete" href="<?php echo esc_url($lead_delete_url); ?>" onclick="return confirm('Move this lead to the trash?');">Remove lead</a><?php endif; ?></td>
                                <td><select class="uturnedu-crm-status <?php echo esc_attr($status_class); ?>" data-lead-id="<?php echo esc_attr($lead->ID); ?>" aria-label="Lead status"><?php foreach (['New','Contacted','Qualified','Follow-up','Applied','Converted','Closed'] as $option): ?><option value="<?php echo esc_attr($option); ?>" <?php selected($status, $option); ?>><?php echo esc_html($option); ?></option><?php endforeach; ?></select><span class="uturnedu-crm-save-state" aria-live="polite"></span></td>
                            </tr>
                        <?php endforeach; else: ?><tr><td colspan="8" class="uturnedu-empty-state">No leads match these filters.</td></tr><?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- ==========================================
             3. TAB: FORMS & SUBMISSIONS
             ========================================== -->
        <div id="tab-forms" class="uturnedu-tab-pane">
            <section class="uturnedu-content-hero uturnedu-forms-hero">
                <div><span class="uturnedu-section-eyebrow">All website enquiries</span><h2>Forms &amp; submissions</h2><p>Every contact, application, eligibility and consultation request is stored safely in the dashboard. Review the submission, follow up, and choose where new notifications should be sent.</p></div>
                <div class="uturnedu-content-hero-actions"><button type="button" class="uturnedu-btn uturnedu-btn-primary" data-tab-jump="tab-leads">Open lead inbox</button><button type="button" class="uturnedu-btn uturnedu-btn-outline" data-tab-jump="tab-appointments">Open bookings</button></div>
            </section>
            <div class="uturnedu-form-overview-grid">
                <article class="uturnedu-card"><span class="uturnedu-mini-stat-icon">✉</span><strong><?php echo esc_html($leads_count); ?></strong><h3>Website lead submissions</h3><p>Modal, contact, apply-now and destination enquiry forms.</p><button type="button" class="uturnedu-text-action" data-tab-jump="tab-leads">Review submissions →</button></article>
                <article class="uturnedu-card"><span class="uturnedu-mini-stat-icon">◷</span><strong><?php echo esc_html($appts_count); ?></strong><h3>Consultation bookings</h3><p>In-person office visits and consultation reservations.</p><button type="button" class="uturnedu-text-action" data-tab-jump="tab-appointments">Review bookings →</button></article>
                <article class="uturnedu-card"><span class="uturnedu-mini-stat-icon">✓</span><strong>Live</strong><h3>Form connections</h3><p>Submissions are connected to the existing WordPress lead and appointment records.</p><span class="uturnedu-form-status">Connected</span></article>
            </div>
            <section class="uturnedu-card uturnedu-form-settings-card"><div class="uturnedu-library-heading"><div><span class="uturnedu-section-eyebrow">Notification settings</span><h3>How should new submissions reach your team?</h3><p>These controls are saved with the agency settings form. Email delivery also depends on your WordPress hosting mail configuration.</p></div><button type="button" class="uturnedu-btn uturnedu-btn-outline uturnedu-btn-sm" data-tab-jump="tab-settings">Open agency settings</button></div><div class="uturnedu-form-connection-list"><div><span>Contact form</span><strong>Creates a lead record</strong></div><div><span>Apply / eligibility form</span><strong>Creates a lead record</strong></div><div><span>Reserve consultation</span><strong>Creates an appointment record</strong></div><div><span>Notification email</span><strong><?php echo esc_html($settings['form_notification_email'] ?? $settings['email_primary'] ?? 'info@ilmaedubd.com'); ?></strong></div></div></section>
        </div>

        <!-- ==========================================
             4. TAB: APPOINTMENTS CRM
             ========================================== -->
        <div id="tab-appointments" class="uturnedu-tab-pane">
            <div class="uturnedu-card">
                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px; flex-wrap:wrap; gap:12px;">
                    <div>
                        <h2 style="margin:0 0 4px 0; font-size:18px; font-weight:700;">Office Visit & Consultation Reservations</h2>
                        <p style="margin:0; font-size:13px; color:#64748B;">Scheduled 1-on-1 counselor appointments at the Mohammadpur Office.</p>
                    </div>
                </div>

                <div class="uturnedu-table-responsive">
                    <table class="uturnedu-table">
                        <thead>
                            <tr>
                                <th>Booking Ref</th>
                                <th>Student Name</th>
                                <th>Phone</th>
                                <th>Reserved Date</th>
                                <th>Slot Time</th>
                                <th>Meeting Type</th>
                                <th>Country Interest</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!empty($recent_appts)): ?>
                                <?php foreach ($recent_appts as $appt):
                                    $ref   = get_post_meta($appt->ID, '_appt_ref', true);
                                    $phone = get_post_meta($appt->ID, '_appt_phone', true);
                                    $date  = get_post_meta($appt->ID, '_appt_date', true);
                                    $time  = get_post_meta($appt->ID, '_appt_slot_time', true) ?: get_post_meta($appt->ID, '_appt_time', true);
                                    $type  = get_post_meta($appt->ID, '_appt_type', true) ?: 'In-Person (Office)';
                                    $dest  = get_post_meta($appt->ID, '_appt_destination', true) ?: get_post_meta($appt->ID, '_appt_country', true);
                                    $status= get_post_meta($appt->ID, '_appt_status', true) ?: 'Confirmed';
                                ?>
                                    <tr>
                                        <td><code style="font-weight:700; color:#0F172A;"><?php echo esc_html($ref ?: 'ILMA-'.substr(md5($appt->ID), 0, 6)); ?></code></td>
                                        <td><strong><?php echo esc_html($appt->post_title); ?></strong></td>
                                        <td><a href="tel:<?php echo esc_attr($phone); ?>" style="color:#2563EB; font-weight:600;"><?php echo esc_html($phone); ?></a></td>
                                        <td><strong><?php echo esc_html($date); ?></strong></td>
                                        <td><span class="uturnedu-badge uturnedu-badge-blue"><?php echo esc_html($time); ?></span></td>
                                        <td style="font-size:12px;"><?php echo esc_html($type); ?></td>
                                        <td><?php echo esc_html($dest ?: 'Any'); ?></td>
                                        <td>
                                            <span class="uturnedu-badge <?php echo $status === 'Confirmed' ? 'uturnedu-badge-confirmed' : ($status === 'Completed' ? 'uturnedu-badge-blue' : 'uturnedu-badge-cancelled'); ?>">
                                                <?php echo esc_html($status); ?>
                                            </span>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr><td colspan="8" style="text-align:center; padding:30px;">No appointments reserved yet.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- ==========================================
             4. TAB: SLOTS CAPACITY
             ========================================== -->
        <div id="tab-slots" class="uturnedu-tab-pane">
            <div class="uturnedu-card">
                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px;">
                    <div>
                        <h2 style="margin:0 0 4px 0; font-size:18px; font-weight:700;">In-Person Consultation Time Slots</h2>
                        <p style="margin:0; font-size:13px; color:#64748B;">Manage student seat capacities and office timing windows (Saturday – Thursday).</p>
                    </div>
                    <div>
                        <a href="<?php echo esc_url(admin_url('post-new.php?post_type=consult_slot')); ?>" class="uturnedu-btn uturnedu-btn-primary">
                            + Add New Time Slot
                        </a>
                    </div>
                </div>

                <div class="uturnedu-table-responsive">
                    <table class="uturnedu-table">
                        <thead>
                            <tr>
                                <th>Slot Name / Timing</th>
                                <th>Max Capacity</th>
                                <th>Total Booked</th>
                                <th>Available Seats</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!empty($slots)): ?>
                                <?php foreach ($slots as $slot):
                                    $cap    = (int) (get_post_meta($slot->ID, '_slot_capacity', true) ?: 4);
                                    $booked = (int) (get_post_meta($slot->ID, '_slot_booked_count', true) ?: 0);
                                    $active = get_post_meta($slot->ID, '_slot_active', true) !== 'no';
                                    $avail  = max(0, $cap - $booked);
                                ?>
                                    <tr>
                                        <td><strong><?php echo esc_html($slot->post_title); ?></strong></td>
                                        <td><?php echo esc_html($cap); ?> Students</td>
                                        <td><?php echo esc_html($booked); ?> Booked</td>
                                        <td>
                                            <strong style="color: <?php echo $avail > 0 ? '#059669' : '#DC2626'; ?>;">
                                                <?php echo $avail > 0 ? $avail . ' Seats Left' : 'Fully Booked'; ?>
                                            </strong>
                                        </td>
                                        <td>
                                            <span class="uturnedu-badge <?php echo $active ? 'uturnedu-badge-confirmed' : 'uturnedu-badge-cancelled'; ?>">
                                                <?php echo $active ? 'Active' : 'Disabled'; ?>
                                            </span>
                                        </td>
                                        <td>
                                            <a href="<?php echo esc_url(get_edit_post_link($slot->ID)); ?>" class="uturnedu-btn uturnedu-btn-outline uturnedu-btn-sm">Edit</a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr><td colspan="6" style="text-align:center; padding:30px;">No slots configured.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- ==========================================
             5. TAB: POPUP BUILDER (IMAGE & TEXTUAL)
             ========================================== -->
        <div id="tab-popup" class="uturnedu-tab-pane">
            <div class="uturnedu-card" style="max-width:840px;">
                <div style="display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:20px;">
                    <div>
                        <h2 style="margin:0 0 4px 0; font-size:18px; font-weight:700;">🎯 5-Second Lead Popup Campaign Builder</h2>
                        <p style="margin:0; font-size:13px; color:#64748B;">Choose between full image banner popups, high-converting textual popups, or split hybrid layouts.</p>
                    </div>
                </div>

                <form method="post" action="">
                    <?php wp_nonce_field('uturnedu_save_settings_action', 'uturnedu_save_settings_nonce'); ?>

                    <div class="uturnedu-form-group">
                        <label class="uturnedu-label">Popup Status</label>
                        <select name="popup_enabled" class="uturnedu-select">
                            <option value="yes" <?php selected($settings['popup_enabled'] ?? 'yes', 'yes'); ?>>✅ Enabled (Active on Frontend)</option>
                            <option value="no" <?php selected($settings['popup_enabled'] ?? 'yes', 'no'); ?>>❌ Disabled (Temporarily Hidden)</option>
                        </select>
                    </div>

                    <!-- POPUP TYPE SELECTOR -->
                    <div class="uturnedu-form-group">
                        <label class="uturnedu-label">Popup Format / Layout</label>
                        <div style="display:grid; grid-template-columns: 1fr 1fr 1fr; gap: 12px; margin-top: 6px;">
                            <label style="border: 2px solid <?php echo ($settings['popup_type'] ?? 'image_and_text') === 'image_and_text' ? '#2563EB' : '#E2E8F0'; ?>; padding: 14px; border-radius: 10px; cursor: pointer; background: #FFF;">
                                <input type="radio" name="popup_type" value="image_and_text" <?php checked($settings['popup_type'] ?? 'image_and_text', 'image_and_text'); ?>>
                                <div style="font-weight: 700; margin-top: 4px;">🖼️ + 📝 Combined Hybrid</div>
                                <div style="font-size: 11px; color: #64748B;">Left image flyer + right text & CTA button.</div>
                            </label>

                            <label style="border: 2px solid <?php echo ($settings['popup_type'] ?? '') === 'image_only' ? '#2563EB' : '#E2E8F0'; ?>; padding: 14px; border-radius: 10px; cursor: pointer; background: #FFF;">
                                <input type="radio" name="popup_type" value="image_only" <?php checked($settings['popup_type'] ?? '', 'image_only'); ?>>
                                <div style="font-weight: 700; margin-top: 4px;">🖼️ Image Banner Only</div>
                                <div style="font-size: 11px; color: #64748B;">Clickable promo flyer banner image.</div>
                            </label>

                            <label style="border: 2px solid <?php echo ($settings['popup_type'] ?? '') === 'textual' ? '#2563EB' : '#E2E8F0'; ?>; padding: 14px; border-radius: 10px; cursor: pointer; background: #FFF;">
                                <input type="radio" name="popup_type" value="textual" <?php checked($settings['popup_type'] ?? '', 'textual'); ?>>
                                <div style="font-weight: 700; margin-top: 4px;">📝 Textual Modal Only</div>
                                <div style="font-size: 11px; color: #64748B;">High-converting text headline & buttons.</div>
                            </label>
                        </div>
                    </div>

                    <!-- Popup Image URL -->
                    <div class="uturnedu-form-group">
                        <label class="uturnedu-label">Popup Banner Image</label>
                        <div class="uturnedu-media-row"><input type="url" id="uturnedu-popup-image" name="popup_image_url" class="uturnedu-input" placeholder="Choose an image from the Media Library" value="<?php echo esc_attr($settings['popup_image_url'] ?? get_template_directory_uri() . '/assets/images/scholarship-celebration.jpg'); ?>"><button type="button" class="uturnedu-media-button" data-media-target="uturnedu-popup-image">Choose image</button></div>
                        <span class="uturnedu-help">Image used for Image-Only and Combined Image+Text popups.</span>
                    </div>

                    <div style="display:grid; grid-template-columns: 1fr 1fr; gap:16px;">
                        <div class="uturnedu-form-group">
                            <label class="uturnedu-label">Delay Before Popup Shows (Seconds)</label>
                            <input type="number" name="popup_delay" class="uturnedu-input" min="1" max="60" value="<?php echo esc_attr($settings['popup_delay'] ?? 5); ?>">
                        </div>

                        <div class="uturnedu-form-group">
                            <label class="uturnedu-label">Display Frequency</label>
                            <select name="popup_frequency" class="uturnedu-select">
                                <option value="session" <?php selected($settings['popup_frequency'] ?? 'session', 'session'); ?>>Once Per Browser Session</option>
                                <option value="day" <?php selected($settings['popup_frequency'] ?? 'session', 'day'); ?>>Once Per Day (24 Hours)</option>
                                <option value="always" <?php selected($settings['popup_frequency'] ?? 'session', 'always'); ?>>Always Show (Testing Mode)</option>
                            </select>
                        </div>
                    </div>

                    <div class="uturnedu-form-group">
                        <label class="uturnedu-label">Popup Headline / Title</label>
                        <input type="text" name="popup_heading" class="uturnedu-input" value="<?php echo esc_attr($settings['popup_heading'] ?? 'Start your study abroad journey with clear, practical guidance.'); ?>">
                    </div>

                    <div class="uturnedu-form-group">
                        <label class="uturnedu-label">Popup Subtitle / Body Copy</label>
                        <textarea name="popup_subheading" class="uturnedu-textarea" rows="3"><?php echo esc_textarea($settings['popup_subheading'] ?? 'Meet certified counselors at our Mohammadpur office or get immediate profile assessment.'); ?></textarea>
                    </div>

                    <div style="display:grid; grid-template-columns: 1fr 1fr; gap:16px;">
                        <div class="uturnedu-form-group">
                            <label class="uturnedu-label">CTA Button Label</label>
                            <input type="text" name="popup_cta_text" class="uturnedu-input" value="<?php echo esc_attr($settings['popup_cta_text'] ?? 'Claim Free Consultation'); ?>">
                        </div>

                        <div class="uturnedu-form-group">
                            <label class="uturnedu-label">CTA Action Type</label>
                            <select name="popup_cta_action" class="uturnedu-select">
                                <option value="modal" <?php selected($settings['popup_cta_action'] ?? 'modal', 'modal'); ?>>Open Free Profile Assessment Modal</option>
                                <option value="link" <?php selected($settings['popup_cta_action'] ?? 'modal', 'link'); ?>>Redirect to Custom URL (Below)</option>
                            </select>
                        </div>
                    </div>

                    <div class="uturnedu-form-group">
                        <label class="uturnedu-label">Custom Target URL (If Action is Redirect)</label>
                        <input type="url" name="popup_cta_url" class="uturnedu-input" placeholder="https://example.com/special-offer" value="<?php echo esc_url($settings['popup_cta_url'] ?? home_url('/reserve-consultation/')); ?>">
                    </div>

                    <button type="submit" class="uturnedu-btn uturnedu-btn-primary" style="padding:12px 28px; margin-top:10px;">
                        💾 Save Popup Settings
                    </button>
                </form>
            </div>
        </div>

        <!-- ==========================================
             6. TAB: MARKETING AD SPACES
             ========================================== -->
        <div id="tab-ads" class="uturnedu-tab-pane">
            <div class="uturnedu-card">
                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px;">
                    <div>
                        <h2 style="margin:0 0 4px 0; font-size:18px; font-weight:700;">Marketing Banners & Ad Spaces</h2>
                        <p style="margin:0; font-size:13px; color:#64748B;">Manage placement banners, destination sidebars, and real-time click tracking.</p>
                    </div>
                    <div>
                        <a href="<?php echo esc_url(admin_url('post-new.php?post_type=ad_banner')); ?>" class="uturnedu-btn uturnedu-btn-primary">
                            + Add New Ad Banner
                        </a>
                    </div>
                </div>

                <div class="uturnedu-table-responsive">
                    <table class="uturnedu-table">
                        <thead>
                            <tr>
                                <th>Banner Title</th>
                                <th>Placement Position</th>
                                <th>Target Link</th>
                                <th>Total Clicks</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!empty($ads)): ?>
                                <?php foreach ($ads as $ad):
                                    $place = get_post_meta($ad->ID, '_ad_placement', true) ?: 'home_middle';
                                    $link = get_post_meta($ad->ID, '_ad_target_url', true);
                                    $clicks = (int) get_post_meta($ad->ID, '_ad_clicks', true);
                                    $act = get_post_meta($ad->ID, '_ad_active', true) !== 'no';
                                ?>
                                    <tr>
                                        <td><strong><?php echo esc_html($ad->post_title); ?></strong></td>
                                        <td><code style="font-weight:600;"><?php echo esc_html($place); ?></code></td>
                                        <td><a href="<?php echo esc_url($link); ?>" target="_blank" style="font-size:12px;"><?php echo esc_html($link ?: 'Self'); ?></a></td>
                                        <td><strong><?php echo esc_html($clicks); ?> Clicks</strong></td>
                                        <td>
                                            <span class="uturnedu-badge <?php echo $act ? 'uturnedu-badge-confirmed' : 'uturnedu-badge-cancelled'; ?>">
                                                <?php echo $act ? 'Active' : 'Paused'; ?>
                                            </span>
                                        </td>
                                        <td>
                                            <a href="<?php echo esc_url(get_edit_post_link($ad->ID)); ?>" class="uturnedu-btn uturnedu-btn-outline uturnedu-btn-sm">Edit</a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr><td colspan="6" style="text-align:center; padding:30px;">No ad spaces created.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- ==========================================
             7. TAB: AGENCY, OFFICE & LOGO SETTINGS
             ========================================== -->
        <div id="tab-settings" class="uturnedu-tab-pane">
            <form method="post" action="">
                <?php wp_nonce_field('uturnedu_save_settings_action', 'uturnedu_save_settings_nonce'); ?>

                <!-- Logo & Brand Customization Card -->
                <div class="uturnedu-card" style="margin-bottom:24px;">
                    <h2 style="margin:0 0 6px 0; font-size:18px; font-weight:700;">🎨 Brand Logos & Visual Identity</h2>
                    <p style="margin:0 0 20px 0; font-size:13px; color:#64748B;">Upload or update header, footer, favicon, and dashboard branding assets.</p>

                    <div style="display:grid; grid-template-columns: 1fr 1fr; gap:20px;">
                        <div class="uturnedu-form-group">
                            <label class="uturnedu-label">Header Primary Logo</label>
                            <div class="uturnedu-media-row"><input type="url" id="uturnedu-site-logo-primary" name="site_logo_primary" class="uturnedu-input" value="<?php echo esc_attr($settings['site_logo_primary'] ?? $default_logo_primary); ?>"><button type="button" class="uturnedu-media-button" data-media-target="uturnedu-site-logo-primary">Choose image</button></div>
                            <span class="uturnedu-help">Main logo displayed on white / light headers.</span>
                        </div>

                        <div class="uturnedu-form-group">
                            <label class="uturnedu-label">Dark / Transparent Footer Logo</label>
                            <div class="uturnedu-media-row"><input type="url" id="uturnedu-site-logo-transparent" name="site_logo_transparent" class="uturnedu-input" value="<?php echo esc_attr($settings['site_logo_transparent'] ?? $default_logo_trans); ?>"><button type="button" class="uturnedu-media-button" data-media-target="uturnedu-site-logo-transparent">Choose image</button></div>
                            <span class="uturnedu-help">Transparent logo used on dark footers and custom login screen.</span>
                        </div>

                        <div class="uturnedu-form-group">
                            <label class="uturnedu-label">Dashboard Logo</label>
                            <div class="uturnedu-media-row"><input type="url" id="uturnedu-site-logo-dashboard" name="site_logo_dashboard" class="uturnedu-input" value="<?php echo esc_attr($settings['site_logo_dashboard'] ?? $default_uturn_logo); ?>"><button type="button" class="uturnedu-media-button" data-media-target="uturnedu-site-logo-dashboard">Choose image</button></div>
                            <span class="uturnedu-help">Optional logo used in the admin workspace.</span>
                        </div>

                        <div class="uturnedu-form-group">
                            <label class="uturnedu-label">Site Favicon</label>
                            <div class="uturnedu-media-row"><input type="url" id="uturnedu-site-favicon" name="site_favicon" class="uturnedu-input" value="<?php echo esc_attr($settings['site_favicon'] ?? ''); ?>" placeholder="Choose a square image"><button type="button" class="uturnedu-media-button" data-media-target="uturnedu-site-favicon">Choose image</button></div>
                            <span class="uturnedu-help">Use a square PNG or SVG for the browser tab icon.</span>
                        </div>

                        <div class="uturnedu-form-group">
                            <label class="uturnedu-label">Official Tagline</label>
                            <input type="text" name="site_tagline" class="uturnedu-input" value="<?php echo esc_attr($settings['site_tagline'] ?? 'Study Abroad, See the World, Build Career!'); ?>">
                        </div>
                        <div class="uturnedu-form-group" style="grid-column: span 2;">
                            <label class="uturnedu-label">Footer description</label>
                            <textarea name="footer_description" class="uturnedu-textarea" rows="3"><?php echo esc_textarea($settings['footer_description'] ?? 'Helping Bangladeshi students make informed international study decisions with clear counselling, application guidance and practical support from shortlist to departure.'); ?></textarea>
                        </div>
                        <div class="uturnedu-form-group" style="grid-column: span 2;">
                            <label class="uturnedu-label">Footer copyright line</label>
                            <input type="text" name="footer_copyright" class="uturnedu-input" value="<?php echo esc_attr($settings['footer_copyright'] ?? 'All Rights Reserved.'); ?>">
                        </div>
                    </div>
                </div>

                <div class="uturnedu-card" style="margin-bottom:24px;">
                    <h2 style="margin:0 0 6px 0; font-size:18px; font-weight:700;">🖼️ Page Visuals</h2>
                    <p style="margin:0 0 20px 0; font-size:13px; color:#64748B;">Replace the supporting images used on the About page. Choose files from the Media Library instead of copying URLs.</p>
                    <div style="display:grid; grid-template-columns:1fr 1fr; gap:20px;">
                        <div class="uturnedu-form-group"><label class="uturnedu-label">About story image</label><div class="uturnedu-media-row"><input type="url" id="uturnedu-about-story-image" name="about_story_image" class="uturnedu-input" value="<?php echo esc_attr($settings['about_story_image'] ?? ''); ?>" placeholder="Default theme image"><button type="button" class="uturnedu-media-button" data-media-target="uturnedu-about-story-image">Choose image</button></div></div>
                        <div class="uturnedu-form-group"><label class="uturnedu-label">Admission counselor image</label><div class="uturnedu-media-row"><input type="url" id="uturnedu-about-admission-image" name="about_admission_image" class="uturnedu-input" value="<?php echo esc_attr($settings['about_admission_image'] ?? ''); ?>" placeholder="Default theme image"><button type="button" class="uturnedu-media-button" data-media-target="uturnedu-about-admission-image">Choose image</button></div></div>
                        <div class="uturnedu-form-group"><label class="uturnedu-label">Visa counselor image</label><div class="uturnedu-media-row"><input type="url" id="uturnedu-about-visa-image" name="about_visa_image" class="uturnedu-input" value="<?php echo esc_attr($settings['about_visa_image'] ?? ''); ?>" placeholder="Default theme image"><button type="button" class="uturnedu-media-button" data-media-target="uturnedu-about-visa-image">Choose image</button></div></div>
                        <div class="uturnedu-form-group"><label class="uturnedu-label">Asia-Pacific counselor image</label><div class="uturnedu-media-row"><input type="url" id="uturnedu-about-asia-image" name="about_asia_image" class="uturnedu-input" value="<?php echo esc_attr($settings['about_asia_image'] ?? ''); ?>" placeholder="Default theme image"><button type="button" class="uturnedu-media-button" data-media-target="uturnedu-about-asia-image">Choose image</button></div></div>
                    </div>
                </div>

                <div class="uturnedu-card" style="margin-bottom:24px;">
                    <h2 style="margin:0 0 6px 0; font-size:18px; font-weight:700;">✎ Core Page Copy</h2>
                    <p style="margin:0 0 20px 0; font-size:13px; color:#64748B;">Update the hero title and introduction shown on the main About, Services, Contact, Apply and Consultation pages.</p>
                    <div class="uturnedu-core-page-copy-grid">
                        <div class="uturnedu-form-group"><label class="uturnedu-label">About page title</label><input type="text" name="about_hero_title" class="uturnedu-input" value="<?php echo esc_attr($settings['about_hero_title'] ?? 'About ILMA Education Consultancy'); ?>"><label class="uturnedu-label">About page introduction</label><textarea name="about_hero_intro" class="uturnedu-textarea" rows="2"><?php echo esc_textarea($settings['about_hero_intro'] ?? 'Practical, ethical and student-first guidance for your study abroad journey.'); ?></textarea></div>
                        <div class="uturnedu-form-group"><label class="uturnedu-label">Services page title</label><input type="text" name="services_hero_title" class="uturnedu-input" value="<?php echo esc_attr($settings['services_hero_title'] ?? 'Our Services'); ?>"><label class="uturnedu-label">Services page introduction</label><textarea name="services_hero_intro" class="uturnedu-textarea" rows="2"><?php echo esc_textarea($settings['services_hero_intro'] ?? 'Explore practical support for each important decision in your application journey.'); ?></textarea></div>
                        <div class="uturnedu-form-group"><label class="uturnedu-label">Contact page title</label><input type="text" name="contact_hero_title" class="uturnedu-input" value="<?php echo esc_attr($settings['contact_hero_title'] ?? 'Contact ILMA Education Consultancy'); ?>"><label class="uturnedu-label">Contact page introduction</label><textarea name="contact_hero_intro" class="uturnedu-textarea" rows="2"><?php echo esc_textarea($settings['contact_hero_intro'] ?? 'Have questions about entry requirements, study destinations or your next application step?'); ?></textarea></div>
                        <div class="uturnedu-form-group"><label class="uturnedu-label">Apply page title</label><input type="text" name="apply_hero_title" class="uturnedu-input" value="<?php echo esc_attr($settings['apply_hero_title'] ?? 'Start your study abroad application'); ?>"><label class="uturnedu-label">Apply page introduction</label><textarea name="apply_hero_intro" class="uturnedu-textarea" rows="2"><?php echo esc_textarea($settings['apply_hero_intro'] ?? 'Share your profile and our advisors will help you understand suitable destinations and next steps.'); ?></textarea></div>
                        <div class="uturnedu-form-group"><label class="uturnedu-label">Consultation page title</label><input type="text" name="reserve_hero_title" class="uturnedu-input" value="<?php echo esc_attr($settings['reserve_hero_title'] ?? 'Reserve In-Person Consultation'); ?>"><label class="uturnedu-label">Consultation page introduction</label><textarea name="reserve_hero_intro" class="uturnedu-textarea" rows="2"><?php echo esc_textarea($settings['reserve_hero_intro'] ?? 'Schedule a dedicated 1-on-1 counselling session at our Mohammadpur office.'); ?></textarea></div>
                    </div>
                </div>

                <!-- Office Location (Mohammadpur / Dynamic) & Contacts -->
                <div class="uturnedu-card" style="margin-bottom:24px;">
                    <div style="border-left: 4px solid #2563EB; padding-left: 12px; margin-bottom: 16px;">
                        <h2 style="margin:0 0 4px 0; font-size:18px; font-weight:700;">🏢 Office Location & Helplines</h2>
                        <p style="margin:0; font-size:13px; color:#64748B;">
                            Current physical address is configured to <strong>Mohammadpur, Dhaka</strong>. Update anytime below to reflect immediately across all pages, footers, and booking calendars.
                        </p>
                    </div>

                    <div style="display:grid; grid-template-columns: 1fr 1fr; gap:20px;">
                        <div class="uturnedu-form-group" style="grid-column: span 2;">
                            <label class="uturnedu-label">Full Office Address <span style="color:#DC2626;">*</span></label>
                            <input type="text" name="address" class="uturnedu-input" value="<?php echo esc_attr($address); ?>" required>
                            <span class="uturnedu-help">Displayed in the footer contact column, Contact Us page, and Google Schema.</span>
                        </div>

                        <div class="uturnedu-form-group">
                            <label class="uturnedu-label">Office Area / City</label>
                            <input type="text" name="office_area" class="uturnedu-input" value="<?php echo esc_attr($settings['office_area'] ?? 'Mohammadpur, Dhaka'); ?>">
                        </div>

                        <div class="uturnedu-form-group">
                            <label class="uturnedu-label">Office Working Hours</label>
                            <input type="text" name="office_hours" class="uturnedu-input" value="<?php echo esc_attr($settings['office_hours'] ?? 'Saturday – Thursday: 10:00 AM – 6:30 PM (Friday Closed)'); ?>">
                        </div>

                        <div class="uturnedu-form-group">
                            <label class="uturnedu-label">Primary Telephone / Mobile</label>
                            <input type="text" name="phone_primary" class="uturnedu-input" value="<?php echo esc_attr($settings['phone_primary'] ?? '01329272046'); ?>">
                        </div>

                        <div class="uturnedu-form-group">
                            <label class="uturnedu-label">Secondary Mobile Helpline</label>
                            <input type="text" name="phone_secondary" class="uturnedu-input" value="<?php echo esc_attr($settings['phone_secondary'] ?? '01823345573'); ?>">
                        </div>

                        <div class="uturnedu-form-group">
                            <label class="uturnedu-label">WhatsApp Hotline (with Country Code)</label>
                            <input type="text" name="whatsapp_number" class="uturnedu-input" value="<?php echo esc_attr($settings['whatsapp_number'] ?? '+8801848638406'); ?>">
                        </div>

                        <div class="uturnedu-form-group">
                            <label class="uturnedu-label">Primary Official Email</label>
                            <input type="email" name="email_primary" class="uturnedu-input" value="<?php echo esc_attr($settings['email_primary'] ?? 'info@ilmaedubd.com'); ?>">
                        </div>

                        <div class="uturnedu-form-group">
                            <label class="uturnedu-label">Support / Senior Counselor Email</label>
                            <input type="email" name="email_support" class="uturnedu-input" value="<?php echo esc_attr($settings['email_support'] ?? 'rawshan@ilmaedubd.com'); ?>">
                        </div>

                        <div class="uturnedu-form-group">
                            <label class="uturnedu-label">Form notification email</label>
                            <input type="email" name="form_notification_email" class="uturnedu-input" value="<?php echo esc_attr($settings['form_notification_email'] ?? $settings['email_primary'] ?? 'info@ilmaedubd.com'); ?>">
                            <span class="uturnedu-help">Destination for future email notifications from website forms.</span>
                        </div>

                        <div class="uturnedu-form-group">
                            <label class="uturnedu-label">Auto-reply preference</label>
                            <select name="form_auto_reply_enabled" class="uturnedu-select"><option value="no" <?php selected($settings['form_auto_reply_enabled'] ?? 'no', 'no'); ?>>Do not send auto-reply</option><option value="yes" <?php selected($settings['form_auto_reply_enabled'] ?? 'no', 'yes'); ?>>Send auto-reply when configured</option></select>
                        </div>

                        <div class="uturnedu-form-group" style="grid-column: span 2;">
                            <label class="uturnedu-label">Form success message</label>
                            <textarea name="form_success_message" class="uturnedu-textarea" rows="2"><?php echo esc_textarea($settings['form_success_message'] ?? 'Thank you. Our team will review your details and contact you shortly.'); ?></textarea>
                        </div>

                        <div class="uturnedu-form-group">
                            <label class="uturnedu-label">Facebook Official Page</label>
                            <input type="url" name="facebook_url" class="uturnedu-input" value="<?php echo esc_url($settings['facebook_url'] ?? 'https://www.facebook.com/ilmaeducationbd'); ?>">
                        </div>

                        <div class="uturnedu-form-group">
                            <label class="uturnedu-label">Instagram Profile</label>
                            <input type="url" name="instagram_url" class="uturnedu-input" value="<?php echo esc_url($settings['instagram_url'] ?? 'https://www.instagram.com/ilmaeducation'); ?>">
                        </div>

                        <div class="uturnedu-form-group">
                            <label class="uturnedu-label">YouTube Channel</label>
                            <input type="url" name="youtube_url" class="uturnedu-input" value="<?php echo esc_url($settings['youtube_url'] ?? 'https://www.youtube.com/@ilmaeducation'); ?>">
                        </div>
                    </div>
                </div>

                <div style="display:flex; gap:16px; align-items:center;">
                    <button type="submit" class="uturnedu-btn uturnedu-btn-primary" style="padding:14px 32px; font-size:15px; font-weight:700;">
                        💾 Save All Settings Sitewide
                    </button>
                    <button type="submit" name="reinstall_starter_content" value="1" class="uturnedu-btn uturnedu-btn-outline" onclick="return confirm('Re-sync all starter content and destinations?');">
                        🔄 Re-sync Starter Data
                    </button>
                </div>
            </form>
        </div>
          </main>
        </div>
    </div>
    <?php
}
