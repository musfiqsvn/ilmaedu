# UTurnEdu1 - WordPress Education Consultancy Theme

**UTurnEdu1** is a self-contained, zero-configuration WordPress theme built for **ILMA Education Consultancy** and education agencies worldwide. Crafted by **UTurn Digital Solutions**.

---

## 🌟 Key Highlights & Architecture

1. **Zero-Configuration Instant Activation (`inc/auto-install.php`)**
   - **Plug and Play:** Simply activate the theme under **Appearance > Themes**.
   - Automatically creates all core pages (`Home`, `About Us`, `Destinations`, `Services`, `Reserve In-Person Consultation`, `Blog & News`, `Contact Us`, `Privacy Policy`, `Terms & Conditions`, `Cookie Policy`, `Disclaimer`, `Refund Policy`).
   - Automatically configures static front page and posts page settings.
   - Automatically builds primary and footer navigation menus.
   - Automatically populates starter data for 6 Study Destinations, 6 Services, Counselors, Testimonials, Blogs, Consultation Time Slots, and Ad Banners.
   - **No Elementor, WPBakery, or XML demo importer required.**

2. **SaaS-Style UTurnEdu Admin Dashboard (`inc/admin-dashboard.php`)**
   - **Overview:** Live metrics for Student Leads, In-Person Bookings, Live Destinations, and Services.
   - **Agency Settings:** Central management of official taglines, office address, phone numbers, emails, WhatsApp hotline, and social profiles.
   - **Leads CRM:** Searchable student inquiries database with instant status updating and **CSV Export**.
   - **Appointments CRM:** In-person 1-on-1 counselor appointment manager with booking reference tracker and **CSV Export**.
   - **Slot Manager:** Add/edit daily consultation time slots, counselor assignments, and seat capacities.
   - **5-Second Dynamic Lead Popup:** Configurable display delay, headlines, subtexts, and session/daily frequency limits.
   - **Ad Spaces Manager:** Manage Header, Mid-page, and Pre-footer promotional banners with real-time click tracking.

3. **In-Person Consultation Reservation Engine (`page-reserve-consultation.php`)**
   - Multi-step interactive booking wizard.
   - Real-time slot availability checking via WordPress AJAX.
   - Capacity tracking preventing double-booking.
   - Generates unique applicant booking reference (e.g., `ILMA-2026-XXXX`).

4. **100% Native WordPress APIs**
   - Built with native Custom Post Types (`destination`, `service`, `testimonial`, `counselor`, `lead`, `appointment`, `consult_slot`, `ad_banner`).
   - Native Custom Meta Boxes with secure nonces and data sanitization.
   - Native AJAX endpoints (`wp_ajax_*` & `wp_ajax_nopriv_*`).

---

## 📁 File Structure

```
uturnedu1/
├── assets/
│   ├── css/
│   │   ├── admin.css
│   │   └── main.css
│   ├── js/
│   │   ├── admin.js
│   │   ├── booking.js
│   │   └── main.js
│   └── images/
│       ├── banner_top.jpg
│       ├── hero_student.jpg
│       ├── home_banner.jpg
│       └── ilma_logo.png
├── inc/
│   ├── admin-dashboard.php
│   ├── ajax-handlers.php
│   ├── auto-install.php
│   ├── custom-post-types.php
│   ├── meta-boxes.php
│   └── setup.php
├── 404.php
├── archive-destination.php
├── archive-service.php
├── footer.php
├── front-page.php
├── functions.php
├── header.php
├── index.php
├── page-about.php
├── page-contact.php
├── page-legal.php
├── page-reserve-consultation.php
├── screenshot.png
├── single-destination.php
├── single-service.php
├── single.php
└── style.css
```

---

## 🚀 Installation & Usage

1. **Upload Theme:**
   - Compress `/home/user/uturnedu1/` into `uturnedu1.zip` (or upload the folder directly to `wp-content/themes/uturnedu1`).
2. **Activate Theme:**
   - In WordPress Admin, navigate to **Appearance > Themes** and click **Activate** on **UTurnEdu1**.
3. **Enjoy Zero Configuration:**
   - Visit the front page — all pages, menus, content, and consultation slots are instantly live!
   - Access **UTurnEdu Dashboard** in the WordPress sidebar to manage leads, appointments, slots, popups, and ad spaces.

---
© UTurn Digital Solutions. All Rights Reserved.
