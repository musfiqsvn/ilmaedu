<?php
/**
 * Template Name: UTurnEdu Homepage
 *
 * 100% exact match with the original design system, layout, and visual fidelity.
 *
 * @package UTurnEdu1
 */

if (!defined('ABSPATH')) {
    exit;
}

get_header();

$settings     = get_option('uturnedu_settings', []);
$stat_unis    = $settings['stat_universities'] ?? '100+';
$stat_free    = $settings['stat_free_consult'] ?? '100%';
$stat_apps    = $settings['stat_successful_apps'] ?? '367+';
$stat_coun    = $settings['stat_counselors'] ?? '09+';
$stat_years   = '12+';
?>

<!-- ==========================================================================
     HERO SECTION
     ========================================================================== -->
<section class="hero-section">
  <div class="hero-glow-1"></div>
  <div class="hero-glow-2"></div>

  <div class="container">
    <div class="hero-grid">
      
      <!-- Left Content -->
      <div>
        <div class="hero-tag">
          <span>✨ 100% Free Study Abroad Guidance Since 2013</span>
        </div>

        <h1 class="hero-title">
          <?php echo esc_html($settings['site_tagline'] ?? 'Study Abroad, See the World, Build Career!'); ?>
        </h1>

        <p class="hero-desc">
          International Application Processing Centre dedicated to guiding students into leading universities that are the best fit for their academic and career goals since 2013.
        </p>

        <div class="hero-ctas">
          <button type="button" class="btn btn-accent btn-lg open-consultancy-modal">
            <span>Get Free Consultancy</span>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>
          </button>

          <a href="<?php echo esc_url(home_url('/reserve-consultation/')); ?>" class="btn btn-outline-white btn-lg">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg>
            <span>Reserve In-Person Slot</span>
          </a>
        </div>

        <!-- Trust Row -->
        <div class="hero-trust-row">
          <div class="trust-item">
            <div class="trust-icon">✓</div>
            <div class="trust-text">100% Free<br>Admission Guidance</div>
          </div>
          <div class="trust-item">
            <div class="trust-icon">★</div>
            <div class="trust-text">100+ Partner<br>Global Universities</div>
          </div>
          <div class="trust-item">
            <div class="trust-icon">📍</div>
            <div class="trust-text">In-Person<br>Counseling Office</div>
          </div>
        </div>
      </div>

      <!-- Right Fast Lead Capture Form -->
      <div>
        <div class="hero-lead-card" id="consultancy">
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.5rem;">
            <span class="section-badge section-badge-accent" style="margin-bottom: 0;">Quick Assessment</span>
            <span style="font-size: 0.8rem; font-weight: 700; color: #059669;">● 100% Free</span>
          </div>
          
          <h3>Get Free Consultancy</h3>
          <p>Submit your profile for instant review by our certified counselors.</p>

          <form class="ajax-lead-form">
            <input type="hidden" name="source" value="Homepage Hero Form">

            <div class="form-group">
              <label class="form-label">Full Name <span class="req">*</span></label>
              <input type="text" name="name" class="form-control" placeholder="e.g. Tanvir Ahmed" required>
            </div>

            <div class="grid grid-2 gap-3">
              <div class="form-group">
                <label class="form-label">Phone Number <span class="req">*</span></label>
                <input type="tel" name="phone" class="form-control" placeholder="01XXXXXXXXX" required>
              </div>

              <div class="form-group">
                <label class="form-label">Email Address <span class="req">*</span></label>
                <input type="email" name="email" class="form-control" placeholder="name@email.com" required>
              </div>
            </div>

            <div class="grid grid-2 gap-3">
              <div class="form-group">
                <label class="form-label">Study Destination</label>
                <select name="target_country" class="form-control">
                  <option value="Canada">Canada</option>
                  <option value="United Kingdom">United Kingdom</option>
                  <option value="USA">USA</option>
                  <option value="Australia">Australia</option>
                  <option value="Malaysia">Malaysia</option>
                  <option value="New Zealand">New Zealand</option>
                </select>
              </div>

              <div class="form-group">
                <label class="form-label">Education Level</label>
                <select name="study_level" class="form-control">
                  <option value="Bachelor Completed">Bachelor Completed</option>
                  <option value="HSC / A-Levels">HSC / A-Levels</option>
                  <option value="Bachelor Running">Bachelor Running</option>
                  <option value="Masters Completed">Masters Completed</option>
                </select>
              </div>
            </div>

            <div class="form-group">
              <label class="form-label">Preferred Program / Questions</label>
              <textarea name="notes" class="form-control" style="min-height: 70px;" placeholder="Tell us your subject interest, GPA, or questions..."></textarea>
            </div>

            <div class="form-check">
              <input type="checkbox" id="heroConsentCheck" required checked>
              <label for="heroConsentCheck">
                I agree to receive free educational guidance from ILMA Education Consultancy counselors.
              </label>
            </div>

            <button type="submit" class="btn btn-accent btn-block btn-lg" style="font-weight: 700;">
              SEND INQUIRY NOW ➔
            </button>
          </form>
        </div>
      </div>

    </div>
  </div>
</section>

<!-- ==========================================================================
     STATISTICS & TRUST BAR
     ========================================================================== -->
<section class="stats-bar-wrapper">
  <div class="container">
    <div class="stats-grid">
      <div class="stat-item">
        <div class="stat-num"><?php echo esc_html($stat_unis); ?></div>
        <div class="stat-label">Partner Universities</div>
      </div>
      <div class="stat-item">
        <div class="stat-num accent"><?php echo esc_html($stat_free); ?></div>
        <div class="stat-label">Free Consultancy</div>
      </div>
      <div class="stat-item">
        <div class="stat-num"><?php echo esc_html($stat_apps); ?></div>
        <div class="stat-label">Applications Successful</div>
      </div>
      <div class="stat-item">
        <div class="stat-num"><?php echo esc_html($stat_coun); ?></div>
        <div class="stat-label">Certified Counselors</div>
      </div>
      <div class="stat-item">
        <div class="stat-num"><?php echo esc_html($stat_years); ?></div>
        <div class="stat-label">Years of Excellence</div>
      </div>
    </div>
  </div>
</section>

<!-- ==========================================================================
     SECTION: ABOUT US (AUTHENTIC SCRAPED CONTENT ENHANCED)
     ========================================================================== -->
<section class="section">
  <div class="container">
    <div class="grid grid-2 gap-10 items-center">
      <div>
        <div style="position: relative;">
          <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/home-page.image1_.5-1024x560.jpg'); ?>" alt="ILMA Education Consultancy - Global Journey" style="border-radius: var(--radius-xl); box-shadow: var(--shadow-xl); width: 100%;">
          
          <div style="position: absolute; bottom: -1.5rem; right: -1.5rem; background: var(--surface-0); border: 2px solid var(--primary-light); border-radius: var(--radius-lg); padding: 1.25rem 1.75rem; box-shadow: var(--shadow-lg); display: flex; align-items: center; gap: 1rem;" class="hide-mobile">
            <div style="width: 48px; height: 48px; border-radius: 50%; background: var(--primary-light); color: var(--primary); display: flex; align-items: center; justify-content: center; font-size: 1.5rem; font-weight: 800;">
              12
            </div>
            <div>
              <div style="font-weight: 800; color: var(--text-main); font-size: 1.05rem;">Years Experience</div>
              <div style="font-size: 0.8rem; color: var(--text-sub);">Serving Students Since 2013</div>
            </div>
          </div>
        </div>
      </div>

      <div>
        <span class="section-badge">About Us Education Consultancy</span>
        <h2 style="margin-bottom: 1.25rem;">Expand Your Journey to Global Insight</h2>
        
        <p style="font-size: 1.05rem; line-height: 1.7; color: var(--text-main); font-weight: 500; margin-bottom: 1.25rem;">
          ILMA Education Consultancy is a reliable and dedicated global education service provider helping students pursue higher studies abroad. Through ILMA Education Consultancy, aspiring students can access study opportunities in the UK, USA, Canada, Malaysia, Australia, and New Zealand.
        </p>

        <p style="margin-bottom: 1.5rem;">
          The experienced team at ILMA Education Consultancy provides authentic, dependable, and resourceful guidance. Our well-trained counselors are dedicated to supporting students with comprehensive services whenever needed, receiving ongoing training from industry experts to ensure knowledge remains current and relevant.
        </p>

        <p style="margin-bottom: 2rem;">
          Our primary goal is to serve as a bridge between students and overseas educational institutions, ensuring that each student finds the best academic destination to match their goals, aspirations, and financial plan.
        </p>

        <div style="display: flex; gap: 1rem; flex-wrap: wrap;">
          <a href="<?php echo esc_url(home_url('/about/')); ?>" class="btn btn-primary">
            <span>Read Our Full Story</span>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>
          </a>
          <a href="<?php echo esc_url(home_url('/reserve-consultation/')); ?>" class="btn btn-outline">
            <span>Book Mohammadpur Appointment</span>
          </a>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- ==========================================================================
     SECTION: STUDY DESTINATIONS (CANADA, USA, UK, AUSTRALIA, MALAYSIA, NZ)
     ========================================================================== -->
<section class="section section-bg-alt">
  <div class="container">
    <div class="section-title-wrap">
      <span class="section-badge section-badge-accent">Explore Global Destinations</span>
      <h2 class="section-title">Where Do You Want to Study?</h2>
      <p class="section-subtitle">
        Our mission is to place students into leading universities that are the right fit for them. Discover top destinations offering work permits, scholarships, and PR pathways.
      </p>
    </div>

    <div class="grid grid-3 gap-8">
      <?php
      $dest_query = new WP_Query([
          'post_type'      => 'destination',
          'posts_per_page' => 6,
          'post_status'    => 'publish',
          'orderby'        => 'menu_order ID',
          'order'          => 'ASC'
      ]);

      if ($dest_query->have_posts()):
          while ($dest_query->have_posts()): $dest_query->the_post();
              $code       = strtolower(get_post_meta(get_the_ID(), '_dest_code', true) ?: 'ca');
              $psw        = get_post_meta(get_the_ID(), '_dest_psw', true) ?: 'Up to 3-Year PGWP';
              $intakes    = get_post_meta(get_the_ID(), '_dest_intakes', true) ?: 'Fall, Winter, Summer';
              
              // Map country image & flag
              $img_name = ($code === 'ca' || $code === 'canada') ? 'canada-1024x683.jpeg' : (($code === 'us' || $code === 'usa') ? 'usa-1024x536.jpeg' : (($code === 'uk') ? 'uk2.jpeg' : (($code === 'au' || $code === 'australia') ? 'aus.jpeg' : (($code === 'my' || $code === 'malaysia') ? 'malay-2.jpeg' : 'new.jpeg'))));
              $flag_name = ($code === 'ca' || $code === 'canada') ? 'canada.png' : (($code === 'us' || $code === 'usa') ? 'united-states-of-america.png' : (($code === 'uk') ? 'united-kingdom-1.png' : (($code === 'au' || $code === 'australia') ? 'flag.png' : (($code === 'my' || $code === 'malaysia') ? 'malaysia.png' : 'new-zealand.png'))));

              $hero_img = get_template_directory_uri() . '/assets/images/' . $img_name;
              $flag_img = get_template_directory_uri() . '/assets/images/' . $flag_name;
      ?>
          <div class="destination-card">
            <div class="dest-img-wrap">
              <img src="<?php echo esc_url($hero_img); ?>" alt="Study in <?php the_title_attribute(); ?>" loading="lazy">
              <div class="dest-flag-badge">
                <img src="<?php echo esc_url($flag_img); ?>" alt="<?php the_title_attribute(); ?> Flag" width="20" height="14">
                <span><?php the_title(); ?></span>
              </div>
            </div>

            <div class="dest-content">
              <h3 class="dest-title">Study in <?php the_title(); ?></h3>
              <p class="dest-desc"><?php echo wp_trim_words(get_the_excerpt(), 20); ?></p>

              <div class="dest-meta-chips">
                <span class="meta-chip">💼 <?php echo esc_html($psw); ?></span>
                <span class="meta-chip">🗓 <?php echo esc_html(explode(',', $intakes)[0]); ?></span>
              </div>

              <div style="display: flex; gap: 0.5rem; margin-top: auto;">
                <a href="<?php the_permalink(); ?>" class="btn btn-outline btn-block btn-sm" style="font-weight: 700;">
                  Read More & Guide →
                </a>
                <button type="button" class="btn btn-accent btn-sm open-consultancy-modal" data-country="<?php the_title_attribute(); ?>">
                  Apply Free
                </button>
              </div>
            </div>
          </div>
      <?php
          endwhile;
          wp_reset_postdata();
      endif;
      ?>
    </div>

    <div style="text-align: center; margin-top: 3.5rem;">
      <a href="<?php echo esc_url(home_url('/destinations/')); ?>" class="btn btn-primary btn-lg">
        <span>Compare All 6 Study Destinations</span>
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>
      </a>
    </div>
  </div>
</section>

<!-- ==========================================================================
     SECTION: EDUCATION & CONSULTANCY SERVICES
     ========================================================================== -->
<section class="section">
  <div class="container">
    <div class="section-title-wrap">
      <span class="section-badge">Our Comprehensive Support</span>
      <h2 class="section-title">Our Education Services</h2>
      <p class="section-subtitle">
        ILMA Education Consultancy is Your Global Academic Partner. We provide practical direction for students aspiring to pursue higher education abroad with 100% FREE counseling and admission support.
      </p>
    </div>

    <div class="grid grid-3 gap-8">
      <?php
      $srv_query = new WP_Query([
          'post_type'      => 'service',
          'posts_per_page' => 6,
          'post_status'    => 'publish',
          'orderby'        => 'menu_order ID',
          'order'          => 'ASC'
      ]);

      if ($srv_query->have_posts()):
          while ($srv_query->have_posts()): $srv_query->the_post();
              $process = get_post_meta(get_the_ID(), '_service_process', true);
              $steps = $process ? explode("\n", $process) : [];
      ?>
          <div class="service-card">
            <div class="service-icon-box">
              <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><polygon points="16.24 7.76 14.12 14.12 7.76 16.24 9.88 9.88 16.24 7.76"></polygon></svg>
            </div>

            <h3 class="service-title"><?php the_title(); ?></h3>
            <p class="service-desc"><?php echo wp_trim_words(get_the_excerpt(), 22); ?></p>

            <?php if (!empty($steps)): ?>
              <ul class="service-bullets">
                <?php foreach (array_slice($steps, 0, 3) as $st): ?>
                  <?php if (trim($st)): ?>
                    <li>
                      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"></polyline></svg>
                      <span><?php echo esc_html(trim($st)); ?></span>
                    </li>
                  <?php endif; ?>
                <?php endforeach; ?>
              </ul>
            <?php endif; ?>

            <div style="margin-top: auto;">
              <a href="<?php the_permalink(); ?>" class="btn btn-outline btn-block btn-sm">
                <span>View Full Details →</span>
              </a>
            </div>
          </div>
      <?php
          endwhile;
          wp_reset_postdata();
      endif;
      ?>
    </div>
  </div>
</section>

<!-- ==========================================================================
     DYNAMIC CAMPAIGN BANNER / ADVERTISEMENT SPACE (HOME_MID)
     ========================================================================== -->
<?php
$mid_ads = get_posts([
    'post_type'      => 'ad_banner',
    'posts_per_page' => 1,
    'post_status'    => 'publish',
    'meta_query'     => [
        ['key' => '_ad_placement', 'value' => 'home_middle'],
        ['key' => '_ad_active', 'value' => 'yes'],
    ]
]);
if (!empty($mid_ads)):
    $m_ad = $mid_ads[0];
    $m_url = get_post_meta($m_ad->ID, '_ad_target_url', true) ?: home_url('/reserve-consultation/');
?>
  <section class="section" style="padding-top: 0;">
    <div class="container">
      <div class="campaign-banner-box">
        <div class="campaign-banner-grid">
          <div>
            <span class="section-badge section-badge-amber" style="margin-bottom: 0.85rem;">
              ⚡ Special Campaign
            </span>
            <h2 style="margin-bottom: 1rem; font-size: 2rem;">
              <?php echo esc_html($m_ad->post_title); ?>
            </h2>
            <p style="color: #E2E8F0; font-size: 1.05rem; margin-bottom: 1.75rem;">
              Studying abroad can offer exciting opportunities, but it comes with financial considerations. We provide the guidance and scholarship solutions to make your journey effortless.
            </p>
            <a href="<?php echo esc_url($m_url); ?>" 
               class="btn btn-accent btn-lg track-ad-click" 
               data-ad-id="<?php echo esc_attr($m_ad->ID); ?>">
              Get Free Guidance
            </a>
          </div>
          <div>
            <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/scholarship-celebration.jpg'); ?>" alt="Scholarship Support" style="border-radius: var(--radius-lg); box-shadow: var(--shadow-xl); width: 100%; max-height: 280px; object-fit: cover;">
          </div>
        </div>
      </div>
    </div>
  </section>
<?php endif; ?>

<!-- ==========================================================================
     SECTION: FINANCIAL SUPPORT & SCHOLARSHIPS
     ========================================================================== -->
<section class="section section-bg-alt">
  <div class="container">
    <div class="grid grid-2 gap-10 items-center">
      <div>
        <span class="section-badge section-badge-amber">Scholarships &amp; Financial Support</span>
        <h2 style="margin-bottom: 1.25rem;">Unlock Up to 100% Tuition Waivers &amp; Institutional Grants</h2>
        
        <p style="font-size: 1.05rem; color: var(--text-main); font-weight: 500; margin-bottom: 1.25rem;">
          <strong>Studying abroad can offer exciting opportunities, but it comes with significant financial challenges</strong>. Tuition fees for international students are often higher. Additionally, living expenses such as housing, food, and travel can add up quickly.
        </p>

        <p style="margin-bottom: 1.5rem;">
          We provide the guidance and proper solutions to make your journey effortless. From discovering merit awards in Canada and the USA to securing £2,000–£10,000 automatic scholarships in the UK, our counselors conduct thorough profile audits to maximize your funding.
        </p>

        <div class="grid grid-2 gap-4" style="margin-bottom: 2rem;">
          <div style="background: var(--surface-0); padding: 1.25rem; border-radius: var(--radius-md); border: 1px solid var(--surface-200);">
            <div style="font-size: 1.25rem; font-weight: 800; color: var(--primary); margin-bottom: 0.25rem;">$2,000 - $25,000</div>
            <div style="font-size: 0.85rem; color: var(--text-muted); font-weight: 600;">Merit Awards Secured</div>
          </div>
          <div style="background: var(--surface-0); padding: 1.25rem; border-radius: var(--radius-md); border: 1px solid var(--surface-200);">
            <div style="font-size: 1.25rem; font-weight: 800; color: var(--accent-emerald); margin-bottom: 0.25rem;">100% Free</div>
            <div style="font-size: 0.85rem; color: var(--text-muted); font-weight: 600;">Scholarship Application Help</div>
          </div>
        </div>

        <button type="button" class="btn btn-accent btn-lg open-consultancy-modal">
          <span>Check My Scholarship Eligibility</span>
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>
        </button>
      </div>

      <div>
        <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/scholarship-celebration.jpg'); ?>" alt="Scholarship Support and Guidance" style="border-radius: var(--radius-xl); box-shadow: var(--shadow-xl); width: 100%;">
      </div>
    </div>
  </div>
</section>

<!-- ==========================================================================
     SECTION: WHY CHOOSE US?
     ========================================================================== -->
<section class="section">
  <div class="container">
    <div class="section-title-wrap">
      <span class="section-badge">Why Trust Us</span>
      <h2 class="section-title">Why Bangladeshi Students Choose Us</h2>
      <p class="section-subtitle">
        We believe higher education is the most transformative decision of your life. Here is why hundreds of students trust us every year.
      </p>
    </div>

    <div class="why-grid">
      <div class="why-card">
        <div class="why-icon">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><path d="M12 6v6l4 2"></path></svg>
        </div>
        <h3 style="font-size: 1.2rem; margin-bottom: 0.5rem;">100% Free Processing</h3>
        <p style="font-size: 0.9rem;">Zero service fees, zero hidden costs, and zero file opening charges. Direct authorized representation.</p>
      </div>

      <div class="why-card">
        <div class="why-icon">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 21h18M3 10h18M5 10v11M9 10v11M15 10v11M19 10v11M12 2L2 7h20L12 2z"></path></svg>
        </div>
        <h3 style="font-size: 1.2rem; margin-bottom: 0.5rem;">100+ Partner Universities</h3>
        <p style="font-size: 0.9rem;">Direct institutional contracts across the UK, USA, Canada, Australia, Malaysia, and New Zealand.</p>
      </div>

      <div class="why-card">
        <div class="why-icon">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M23 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path></svg>
        </div>
        <h3 style="font-size: 1.2rem; margin-bottom: 0.5rem;">Certified Counselors</h3>
        <p style="font-size: 0.9rem;">Our 9+ senior counselors undergo continuous training with international admission delegates to provide authentic advice.</p>
      </div>

      <div class="why-card">
        <div class="why-icon">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>
        </div>
        <h3 style="font-size: 1.2rem; margin-bottom: 0.5rem;">Mock Visa Interviews</h3>
        <p style="font-size: 0.9rem;">Rigorous 1-on-1 mock interview preparation for USA F-1, UK credibility interviews, and Australian Genuine Student statements.</p>
      </div>

      <div class="why-card">
        <div class="why-icon">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle></svg>
        </div>
        <h3 style="font-size: 1.2rem; margin-bottom: 0.5rem;">In-Person Counseling Office</h3>
        <p style="font-size: 0.9rem;">Conveniently located at CL Tower, 772/1A, Bosila Road, Mohammadpur, Dhaka - 1207, Bangladesh Walk in or reserve a slot to speak with counselors in person.</p>
      </div>

      <div class="why-card">
        <div class="why-icon">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line><polyline points="10 9 9 9 8 9"></polyline></svg>
        </div>
        <h3 style="font-size: 1.2rem; margin-bottom: 0.5rem;">End-to-End Assistance</h3>
        <p style="font-size: 0.9rem;">From SOP drafting and offer letter processing to bank fund verification, housing search, and flight orientation.</p>
      </div>
    </div>
  </div>
</section>

<!-- ==========================================================================
     SECTION: TESTIMONIALS (WHAT OUR STUDENTS SAY ABOUT US)
     ========================================================================== -->
<section class="section section-bg-alt">
  <div class="container">
    <div class="section-title-wrap">
      <span class="section-badge section-badge-accent">Student Success Stories</span>
      <h2 class="section-title">What Our Students Say About Us</h2>
      <p class="section-subtitle">
        Authentic reviews from Bangladeshi students who fulfilled their global higher study aspirations with Us.
      </p>
    </div>

    <div class="grid grid-3 gap-8">
      <?php
      $testi_query = new WP_Query([
          'post_type'      => 'testimonial',
          'posts_per_page' => 3,
          'post_status'    => 'publish',
      ]);

      if ($testi_query->have_posts()):
          while ($testi_query->have_posts()): $testi_query->the_post();
              $country    = get_post_meta(get_the_ID(), '_testi_country', true) ?: 'Abroad';
              $university = get_post_meta(get_the_ID(), '_testi_university', true) ?: 'Partner University';
              $program    = get_post_meta(get_the_ID(), '_testi_program', true) ?: 'Degree Program';
              $rating     = (int) (get_post_meta(get_the_ID(), '_testi_rating', true) ?: 5);
      ?>
          <div class="testimonial-card">
            <div class="stars-row">
              <?php echo str_repeat('★', $rating); ?>
            </div>

            <p class="testimonial-quote">
              "<?php echo esc_html(get_the_content()); ?>"
            </p>

            <div class="testimonial-author">
              <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/WhatsApp-Image-2025-09-21-at-12.00.19-PM-819x1024.jpeg'); ?>" alt="<?php the_title_attribute(); ?>" class="author-avatar" loading="lazy">
              <div>
                <div class="author-name"><?php the_title(); ?></div>
                <div class="author-meta"><?php echo esc_html($program); ?> • <strong><?php echo esc_html($university); ?></strong> (<?php echo esc_html($country); ?>)</div>
              </div>
            </div>
          </div>
      <?php
          endwhile;
          wp_reset_postdata();
      endif;
      ?>
    </div>
  </div>
</section>

<!-- ==========================================================================
     SECTION: PHYSICAL CONSULTATION APPOINTMENT TEASER
     ========================================================================== -->
<section class="section section-bg-dark">
  <div class="container">
    <div class="grid grid-2 gap-10 items-center">
      <div>
        <span class="section-badge section-badge-amber" style="background: rgba(245, 158, 11, 0.2); color: #FEF08A;">
          📍 Office Address
        </span>
        <h2 style="margin-bottom: 1.25rem;">Meet Our Senior Counselors In-Person</h2>
        <p style="font-size: 1.05rem; margin-bottom: 1.5rem;">
          Want to discuss your documents, credit transfer, or budget face-to-face? Reserve a dedicated 1-on-1 consultation slot at our office.
        </p>
        
        <ul style="list-style: none; margin-bottom: 2rem;">
          <li style="display: flex; align-items: center; gap: 0.75rem; margin-bottom: 0.75rem; color: #E2E8F0;">
            <span style="color: #FEF08A; font-weight: 800;">✓</span> CL Tower, 772/1A, Bosila Road, Mohammadpur, Dhaka - 1207, Bangladesh
          </li>
          <li style="display: flex; align-items: center; gap: 0.75rem; margin-bottom: 0.75rem; color: #E2E8F0;">
            <span style="color: #FEF08A; font-weight: 800;">✓</span> Saturday through Thursday: 10:00 AM – 6:30 PM
          </li>
          <li style="display: flex; align-items: center; gap: 0.75rem; color: #E2E8F0;">
            <span style="color: #FEF08A; font-weight: 800;">✓</span> Guaranteed no waiting time when you reserve your slot
          </li>
        </ul>

        <a href="<?php echo esc_url(home_url('/reserve-consultation/')); ?>" class="btn btn-accent btn-lg" style="font-weight: 700;">
          <span>Reserve In-Person Appointment Now</span>
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>
        </a>
      </div>

      <div>
        <div style="background: rgba(255, 255, 255, 0.06); border: 1px solid rgba(255, 255, 255, 0.15); border-radius: var(--radius-xl); padding: 2rem; backdrop-filter: blur(10px);">
          <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/counseling-session.jpg'); ?>" alt="In-person counseling session in Mohammadpur" style="border-radius: var(--radius-lg); width: 100%; box-shadow: var(--shadow-lg);">
          <div style="text-align: center; margin-top: 1.25rem; font-size: 0.9rem; color: #CBD5E1;">
            Personalized 1-on-1 Guidance with Zero Waiting Time
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- ==========================================================================
     SECTION: LATEST BLOG & STUDY GUIDES (AUTHENTIC CONTENT PRESERVED)
     ========================================================================== -->
<section class="section">
  <div class="container">
    <div style="display: flex; justify-content: space-between; align-items: flex-end; margin-bottom: 3rem; flex-wrap: wrap; gap: 1rem;">
      <div>
        <span class="section-badge">Knowledge Hub</span>
        <h2>Latest Study Abroad Articles</h2>
      </div>
      <a href="<?php echo esc_url(home_url('/blogs/')); ?>" class="btn btn-outline" style="font-weight: 700;">
        <span>View All Articles →</span>
      </a>
    </div>

    <div class="grid grid-3 gap-8">
      <?php
      $blog_query = new WP_Query([
          'post_type'      => 'post',
          'posts_per_page' => 3,
          'post_status'    => 'publish',
      ]);

      if ($blog_query->have_posts()):
          while ($blog_query->have_posts()): $blog_query->the_post();
      ?>
          <div class="blog-card">
            <div class="blog-img-wrap">
              <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/uk2.jpeg'); ?>" alt="<?php the_title_attribute(); ?>" loading="lazy">
              <span class="blog-cat-badge">Study Guide</span>
            </div>

            <div class="blog-content">
              <div class="blog-meta-row">
                <span>5 Min Read</span>
                <span>•</span>
                <span><?php echo esc_html(get_the_date('M j, Y')); ?></span>
              </div>

              <h3 class="blog-title">
                <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
              </h3>

              <p class="blog-excerpt">
                <?php echo wp_trim_words(get_the_excerpt(), 18); ?>
              </p>

              <div style="margin-top: auto;">
                <a href="<?php the_permalink(); ?>" style="color: var(--primary); font-weight: 700; font-size: 0.9rem; display: inline-flex; align-items: center; gap: 0.35rem;">
                  <span>Read Article</span>
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>
                </a>
              </div>
            </div>
          </div>
      <?php
          endwhile;
          wp_reset_postdata();
      endif;
      ?>
    </div>
  </div>
</section>

<!-- ==========================================================================
     SECTION: BOTTOM CALL TO ACTION
     ========================================================================== -->
<section class="section section-bg-alt" style="border-top: 1px solid var(--surface-200);">
  <div class="container text-center">
    <div class="section-title-wrap">
      <span class="section-badge section-badge-accent">Ready to Start?</span>
      <h2 class="section-title">Take the First Step Toward Your Global Degree</h2>
      <p class="section-subtitle">
        Join over 367+ Bangladeshi students successfully placed in top universities across Canada, USA, UK, Australia, Malaysia, and New Zealand.
      </p>

      <div style="display: flex; gap: 1rem; justify-content: center; margin-top: 2rem; flex-wrap: wrap;">
        <button type="button" class="btn btn-accent btn-lg open-consultancy-modal">
          <span>Get Free Consultancy</span>
        </button>
        <a href="<?php echo esc_url(home_url('/reserve-consultation/')); ?>" class="btn btn-primary btn-lg">
          <span>Reserve In-Person Appointment</span>
        </a>
      </div>
    </div>
  </div>
</section>

<?php
get_footer();
