<?php
/**
 * Archive Template for Destinations - Exact 1:1 Match
 *
 * @package UTurnEdu1
 */

if (!defined('ABSPATH')) {
    exit;
}

get_header();
?>

<section class="section section-bg-alt" style="padding: 4rem 0 3rem 0;">
  <div class="container text-center">
    <span class="section-badge">Global Horizons</span>
    <h1 style="margin-top: 0.5rem; margin-bottom: 1rem;">Study Abroad Destinations</h1>
    <p style="max-width: 720px; margin: 0 auto; font-size: 1.1rem;">
      Choose from the world's most sought-after higher education destinations. Explore admission criteria, tuition fee benchmarks, scholarship quotas, and post-study work visas.
    </p>
  </div>
</section>

<!-- Country Grid -->
<section class="section">
  <div class="container">
    <div class="grid grid-3 gap-8">
      <?php
      if (have_posts()):
          while (have_posts()): the_post();
              $code    = strtolower(get_post_meta(get_the_ID(), '_dest_code', true) ?: 'ca');
              $psw     = get_post_meta(get_the_ID(), '_dest_psw', true) ?: 'Up to 3-Year PGWP';
              $intakes = get_post_meta(get_the_ID(), '_dest_intakes', true) ?: 'Fall, Winter, Summer';
              
              $img_name = ($code === 'ca' || $code === 'canada') ? 'canada-1024x683.jpeg' : (($code === 'us' || $code === 'usa') ? 'usa-1024x536.jpeg' : (($code === 'uk') ? 'uk2.jpeg' : (($code === 'au' || $code === 'australia') ? 'aus.jpeg' : (($code === 'my' || $code === 'malaysia') ? 'malay-2.jpeg' : 'new.jpeg'))));
              $flag_name = ($code === 'ca' || $code === 'canada') ? 'canada.png' : (($code === 'us' || $code === 'usa') ? 'united-states-of-america.png' : (($code === 'uk') ? 'united-kingdom-1.png' : (($code === 'au' || $code === 'australia') ? 'flag.png' : (($code === 'my' || $code === 'malaysia') ? 'malaysia.png' : 'new-zealand.png'))));

              $hero_img = get_template_directory_uri() . '/assets/images/' . $img_name;
              $flag_img = get_template_directory_uri() . '/assets/images/' . $flag_name;
      ?>
          <div class="destination-card">
            <div class="dest-img-wrap">
              <img src="<?php echo esc_url($hero_img); ?>" alt="Study in <?php the_title_attribute(); ?>" loading="lazy">
              <div class="dest-flag-badge">
                <img src="<?php echo esc_url($flag_img); ?>" alt="<?php the_title_attribute(); ?> Flag" width="20" height="14">
                <span><?php the_title(); ?></span>
              </div>
            </div>

            <div class="dest-content">
              <h3 class="dest-title">Study in <?php the_title(); ?></h3>
              <p class="dest-desc"><?php echo wp_trim_words(get_the_excerpt(), 20); ?></p>

              <div class="dest-meta-chips">
                <span class="meta-chip">💼 <?php echo esc_html($psw); ?></span>
                <span class="meta-chip">🗓 <?php echo esc_html(explode(',', $intakes)[0]); ?></span>
              </div>

              <div style="display: flex; gap: 0.5rem; margin-top: auto;">
                <a href="<?php the_permalink(); ?>" class="btn btn-primary btn-block btn-sm" style="font-weight: 700;">
                  Explore Complete Guide →
                </a>
                <button type="button" class="btn btn-accent btn-sm open-consultancy-modal" data-country="<?php the_title_attribute(); ?>">
                  Apply
                </button>
              </div>
            </div>
          </div>
      <?php
          endwhile;
      endif;
      ?>
    </div>
  </div>
</section>

<!-- Comparison Table Matrix -->
<section class="section section-bg-alt">
  <div class="container">
    <div class="section-title-wrap">
      <span class="section-badge section-badge-accent">Quick Comparison</span>
      <h2 class="section-title">Compare Key Metrics Across Destinations</h2>
      <p class="section-subtitle">
        Evaluate tuition, post-graduation work permits, and English language entry benchmarks.
      </p>
    </div>

    <div class="data-table-wrapper" style="overflow-x: auto;">
      <table class="data-table">
        <thead>
          <tr>
            <th>Country</th>
            <th>Average Tuition / Year</th>
            <th>Post-Study Work Permit</th>
            <th>Part-Time Work Rights</th>
            <th>Key Intakes</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td><strong>🇨🇦 Canada</strong></td>
            <td>CAD $15,000 - $35,000</td>
            <td>Up to 3-Year PGWP</td>
            <td>24 hrs/week</td>
            <td>Sep, Jan, May</td>
            <td><a href="<?php echo esc_url(home_url('/destinations/canada/')); ?>" class="btn btn-outline btn-sm">Guide →</a></td>
          </tr>
          <tr>
            <td><strong>🇺🇸 USA</strong></td>
            <td>USD $18,000 - $45,000</td>
            <td>1 - 3 Years (STEM OPT)</td>
            <td>20 hrs/week on-campus</td>
            <td>Aug/Sep, Jan</td>
            <td><a href="<?php echo esc_url(home_url('/destinations/usa/')); ?>" class="btn btn-outline btn-sm">Guide →</a></td>
          </tr>
          <tr>
            <td><strong>🇬🇧 United Kingdom</strong></td>
            <td>£12,000 - £22,000</td>
            <td>2 Years (Graduate Route)</td>
            <td>20 hrs/week</td>
            <td>Sep/Oct, Jan/Feb</td>
            <td><a href="<?php echo esc_url(home_url('/destinations/uk/')); ?>" class="btn btn-outline btn-sm">Guide →</a></td>
          </tr>
          <tr>
            <td><strong>🇦🇺 Australia</strong></td>
            <td>AUD $22,000 - $42,000</td>
            <td>2 to 4+ Years (Subclass 485)</td>
            <td>48 hrs/fortnight</td>
            <td>Feb, Jul, Nov</td>
            <td><a href="<?php echo esc_url(home_url('/destinations/australia/')); ?>" class="btn btn-outline btn-sm">Guide →</a></td>
          </tr>
          <tr>
            <td><strong>🇲🇾 Malaysia</strong></td>
            <td>USD $3,500 - $9,000</td>
            <td>UK/Aus Twinning Transfers</td>
            <td>20 hrs/week (breaks)</td>
            <td>Sep, Jan, May</td>
            <td><a href="<?php echo esc_url(home_url('/destinations/malaysia/')); ?>" class="btn btn-outline btn-sm">Guide →</a></td>
          </tr>
          <tr>
            <td><strong>🇳🇿 New Zealand</strong></td>
            <td>NZD $22,000 - $35,000</td>
            <td>Up to 3-Year PSWV</td>
            <td>20 hrs/week</td>
            <td>Feb, Jul</td>
            <td><a href="<?php echo esc_url(home_url('/destinations/new-zealand/')); ?>" class="btn btn-outline btn-sm">Guide →</a></td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</section>

<?php
get_footer();
