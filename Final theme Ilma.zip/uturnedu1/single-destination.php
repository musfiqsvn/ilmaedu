<?php
/**
 * Single Destination Template - Exact 1:1 Match
 *
 * @package UTurnEdu1
 */

if (!defined('ABSPATH')) {
    exit;
}

get_header();

$code        = strtolower(get_post_meta(get_the_ID(), '_dest_code', true) ?: 'ca');
$tuition     = get_post_meta(get_the_ID(), '_dest_tuition', true) ?: 'CAD $15,000 - $35,000 / Year';
$psw         = get_post_meta(get_the_ID(), '_dest_psw', true) ?: 'Up to 3-Year PGWP';
$work_rights = get_post_meta(get_the_ID(), '_dest_work_rights', true) ?: '20 hrs/week';
$ielts_req   = get_post_meta(get_the_ID(), '_dest_ielts', true) ?: 'Overall 6.0 - 6.5';
$intakes     = get_post_meta(get_the_ID(), '_dest_intakes', true) ?: 'Fall (Sep), Winter (Jan)';
$living      = get_post_meta(get_the_ID(), '_dest_living_cost', true) ?: '$10,000 - $14,000 / Year';
$universities = get_post_meta(get_the_ID(), '_dest_universities', true) ?: 'Top Accredited Partner Universities';

$img_name = ($code === 'ca' || $code === 'canada') ? 'canada-1024x683.jpeg' : (($code === 'us' || $code === 'usa') ? 'usa-1024x536.jpeg' : (($code === 'uk') ? 'uk2.jpeg' : (($code === 'au' || $code === 'australia') ? 'aus.jpeg' : (($code === 'my' || $code === 'malaysia') ? 'malay-2.jpeg' : 'new.jpeg'))));
$flag_name = ($code === 'ca' || $code === 'canada') ? 'canada.png' : (($code === 'us' || $code === 'usa') ? 'united-states-of-america.png' : (($code === 'uk') ? 'united-kingdom-1.png' : (($code === 'au' || $code === 'australia') ? 'flag.png' : (($code === 'my' || $code === 'malaysia') ? 'malaysia.png' : 'new-zealand.png'))));

$hero_img = get_template_directory_uri() . '/assets/images/' . $img_name;
$flag_img = get_template_directory_uri() . '/assets/images/' . $flag_name;
?>

<!-- Destination Hero -->
<section class="hero-section" style="padding: 4rem 0 4.5rem 0;">
  <div class="container">
    <div style="display: flex; align-items: center; gap: 0.75rem; margin-bottom: 1rem;">
      <a href="<?php echo esc_url(home_url('/destinations/')); ?>" style="color: #FEF08A; font-size: 0.85rem; font-weight: 600;">← All Destinations</a>
      <span style="color: rgba(255, 255, 255, 0.4);">/</span>
      <span style="color: #fff; font-size: 0.85rem;"><?php the_title(); ?></span>
    </div>

    <div class="grid grid-2 gap-8 items-center">
      <div>
        <div class="dest-flag-badge" style="position: static; display: inline-flex; margin-bottom: 1rem;">
          <img src="<?php echo esc_url($flag_img); ?>" alt="<?php the_title_attribute(); ?> Flag" width="22" height="15">
          <span>Official Study Guide</span>
        </div>

        <h1 class="hero-title" style="font-size: clamp(2.2rem, 3.8vw, 3.2rem);">
          Study in <?php the_title(); ?>
        </h1>

        <p class="hero-desc" style="margin-bottom: 1.75rem;">
          Discover comprehensive admission criteria, tuition benchmarks, post-study work permits, and scholarship opportunities for Bangladeshi scholars.
        </p>

        <div style="display: flex; gap: 1rem; flex-wrap: wrap;">
          <button type="button" class="btn btn-accent btn-lg open-consultancy-modal" data-country="<?php the_title_attribute(); ?>">
            <span>Apply to <?php the_title(); ?> Universities</span>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>
          </button>
          <a href="<?php echo esc_url(home_url('/reserve-consultation/')); ?>" class="btn btn-outline-white btn-lg">
            <span>Book Mohammadpur Session</span>
          </a>
        </div>
      </div>

      <div>
        <img src="<?php echo esc_url($hero_img); ?>" alt="Study in <?php the_title_attribute(); ?>" style="border-radius: var(--radius-xl); box-shadow: var(--shadow-xl); width: 100%; max-height: 380px; object-fit: cover; border: 2px solid rgba(255,255,255,0.15);">
      </div>
    </div>
  </div>
</section>

<!-- Quick Facts Strip -->
<section style="background: var(--surface-50); border-bottom: 1px solid var(--surface-200); padding: 1.75rem 0;">
  <div class="container">
    <div class="grid grid-4 gap-4">
      <div style="background: var(--surface-0); padding: 1.25rem; border-radius: var(--radius-md); border: 1px solid var(--surface-200);">
        <div style="font-size: 0.75rem; text-transform: uppercase; color: var(--text-sub); font-weight: 700;">Tuition Fees</div>
        <div style="font-size: 1.05rem; font-weight: 800; color: var(--primary); margin-top: 0.25rem;"><?php echo esc_html($tuition); ?></div>
      </div>
      <div style="background: var(--surface-0); padding: 1.25rem; border-radius: var(--radius-md); border: 1px solid var(--surface-200);">
        <div style="font-size: 0.75rem; text-transform: uppercase; color: var(--text-sub); font-weight: 700;">Post-Study Work</div>
        <div style="font-size: 1.05rem; font-weight: 800; color: var(--accent-red); margin-top: 0.25rem;"><?php echo esc_html($psw); ?></div>
      </div>
      <div style="background: var(--surface-0); padding: 1.25rem; border-radius: var(--radius-md); border: 1px solid var(--surface-200);">
        <div style="font-size: 0.75rem; text-transform: uppercase; color: var(--text-sub); font-weight: 700;">Part-Time Work</div>
        <div style="font-size: 1.05rem; font-weight: 800; color: var(--accent-emerald); margin-top: 0.25rem;"><?php echo esc_html($work_rights); ?></div>
      </div>
      <div style="background: var(--surface-0); padding: 1.25rem; border-radius: var(--radius-md); border: 1px solid var(--surface-200);">
        <div style="font-size: 0.75rem; text-transform: uppercase; color: var(--text-sub); font-weight: 700;">English Benchmark</div>
        <div style="font-size: 0.95rem; font-weight: 700; color: var(--text-main); margin-top: 0.25rem;"><?php echo esc_html($ielts_req); ?></div>
      </div>
    </div>
  </div>
</section>

<!-- Main Guide Content + Sticky Sidebar Form -->
<section class="section">
  <div class="container">
    <div class="grid" style="grid-template-columns: 2fr 1fr; gap: 3.5rem;">
      <div>
        <div class="dest-rich-content">
          <?php the_content(); ?>
        </div>

        <div style="margin-top: 3rem;">
          <h3 style="font-size: 1.5rem; margin-bottom: 1.25rem;">Key Intakes & Deadlines</h3>
          <p style="margin-bottom: 1.5rem;">Primary entry points for universities across <?php the_title(); ?>:</p>
          <div style="background: var(--surface-50); padding: 1.5rem; border-radius: var(--radius-md); border: 1px solid var(--surface-200);">
            <strong>Intakes:</strong> <?php echo esc_html($intakes); ?>
          </div>
        </div>

        <div style="margin-top: 3rem;">
          <h3 style="font-size: 1.5rem; margin-bottom: 1.25rem;">Top Partner Universities</h3>
          <div style="display: flex; flex-wrap: wrap; gap: 0.75rem;">
            <?php
            $unis_arr = explode(',', $universities);
            foreach ($unis_arr as $uni) {
                if (trim($uni)) {
                    ?>
                    <div style="background: var(--surface-50); border: 1px solid var(--surface-200); padding: 0.5rem 1rem; border-radius: var(--radius-full); font-size: 0.875rem; font-weight: 600;">
                      🏛️ <?php echo esc_html(trim($uni)); ?>
                    </div>
                    <?php
                }
            }
            ?>
          </div>
        </div>
      </div>

      <!-- Sticky Sidebar Lead Form -->
      <div>
        <div style="position: sticky; top: 100px; background: var(--surface-0); border: 1px solid var(--surface-200); border-radius: var(--radius-lg); padding: 2rem; box-shadow: var(--shadow-md);">
          <span class="section-badge section-badge-accent" style="margin-bottom: 0.75rem;">100% Free Service</span>
          <h3 style="font-size: 1.35rem; margin-bottom: 0.5rem;">Study in <?php the_title(); ?></h3>
          <p style="font-size: 0.85rem; color: var(--text-muted); margin-bottom: 1.5rem;">
            Submit your profile for an instant eligibility review and scholarship evaluation.
          </p>

          <form class="ajax-lead-form">
            <input type="hidden" name="source" value="Single Destination (<?php the_title_attribute(); ?>)">
            <input type="hidden" name="target_country" value="<?php the_title_attribute(); ?>">

            <div class="form-group">
              <label class="form-label">Full Name <span class="req">*</span></label>
              <input type="text" name="name" class="form-control" placeholder="e.g. Tanvir Ahmed" required>
            </div>

            <div class="form-group">
              <label class="form-label">Mobile Number <span class="req">*</span></label>
              <input type="tel" name="phone" class="form-control" placeholder="01XXXXXXXXX" required>
            </div>

            <div class="form-group">
              <label class="form-label">Email Address <span class="req">*</span></label>
              <input type="email" name="email" class="form-control" placeholder="student@gmail.com" required>
            </div>

            <div class="form-group">
              <label class="form-label">Education Level</label>
              <select name="study_level" class="form-control">
                <option value="Bachelor Completed">Bachelor Completed</option>
                <option value="HSC / A-Levels">HSC / A-Levels</option>
                <option value="Bachelor Running">Bachelor Running</option>
                <option value="Masters Completed">Masters Completed</option>
              </select>
            </div>

            <button type="submit" class="btn btn-accent btn-block" style="font-weight: 700; padding: 0.85rem;">
              Apply for <?php the_title(); ?> Free ➔
            </button>
          </form>

          <div style="border-top: 1px solid var(--surface-200); margin-top: 1.5rem; padding-top: 1rem; text-align: center;">
            <a href="<?php echo esc_url(home_url('/reserve-consultation/')); ?>" style="font-size: 0.85rem; color: var(--primary); font-weight: 700;">
              Prefer In-Person at Mohammadpur? Book Slot →
            </a>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<?php
get_footer();
