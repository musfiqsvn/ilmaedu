<?php
/**
 * UTurnEdu1 Header Template - Exact 1:1 Match with Original Design
 *
 * @package UTurnEdu1
 */

if (!defined('ABSPATH')) {
    exit;
}

$settings     = get_option('uturnedu_settings', []);
$phone1       = $settings['phone_primary'] ?? '01329272046';
$phone2       = $settings['phone_secondary'] ?? '01823345573';
$email        = $settings['email_primary'] ?? 'info@ilmaedubd.com';
$address      = !empty($settings['address']) ? $settings['address'] : 'CL Tower, 772/1A, Bosila Road, Mohammadpur, Dhaka - 1207, Bangladesh';
$logo_rgb     = get_template_directory_uri() . '/assets/images/ILMA-Education-logo-rgb.png';
$favicon      = get_template_directory_uri() . '/assets/images/canada.png';
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
  <meta charset="<?php bloginfo('charset'); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="icon" type="image/png" href="<?php echo esc_url($favicon); ?>">
  <?php wp_head(); ?>
  <!-- Schema.org JSON-LD Structured Data -->
  <script type="application/ld+json">
  {
    "@context": "https://schema.org",
    "@type": "EducationalOrganization",
    "name": "ILMA Education Consultancy",
    "url": "<?php echo esc_url(home_url('/')); ?>",
    "logo": "<?php echo esc_url($logo_rgb); ?>",
    "description": "International Application Processing Centre dedicated to guiding students into leading universities worldwide since 2013.",
    "telephone": "+8801329272046",
    "email": "info@ilmaedubd.com",
    "address": {
      "@type": "PostalAddress",
      "streetAddress": "CL Tower, 772/1A, Bosila Road",
      "addressLocality": "Mohammadpur",
      "addressRegion": "Dhaka",
      "postalCode": "1207",
      "addressCountry": "BD"
    }
  }
  </script>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<div class="site-boxed-container">

  <!-- Top Announcement Bar / Header Ad Placement -->
  <?php
  $header_ads = get_posts([
      'post_type'      => 'ad_banner',
      'posts_per_page' => 1,
      'post_status'    => 'publish',
      'meta_query'     => [
          ['key' => '_ad_placement', 'value' => 'header_top'],
          ['key' => '_ad_active', 'value' => 'yes'],
      ]
  ]);
  if (!empty($header_ads)) {
      $h_ad = $header_ads[0];
      $h_url = get_post_meta($h_ad->ID, '_ad_target_url', true) ?: home_url('/reserve-consultation/');
      ?>
      <div class="top-notice-bar">
        <span>⚡ 2026/2027 Admissions Open!</span>
        <span><?php echo esc_html($h_ad->post_title); ?> — Apply with 100% Free Processing.</span>
        <a href="<?php echo esc_url($h_url); ?>" class="track-ad-click" data-ad-id="<?php echo esc_attr($h_ad->ID); ?>">Reserve In-Person Slot →</a>
      </div>
      <?php
  } else {
      ?>
      <div class="top-notice-bar">
        <span>⚡ 2026/2027 Admissions Open!</span>
        <span>Apply for UK, Canada, USA, Australia, Malaysia & New Zealand with 100% Free Processing.</span>
        <a href="<?php echo esc_url(home_url('/reserve-consultation/')); ?>">Reserve In-Person Slot →</a>
      </div>
      <?php
  }
  ?>

  <!-- Sticky Header -->
  <header class="header-wrapper">
    <div class="container">
      <div class="header-inner">
        
        <!-- Brand Logo -->
        <a href="<?php echo esc_url(home_url('/')); ?>" class="brand-logo" title="ILMA Education Consultancy">
          <img src="<?php echo esc_url($logo_rgb); ?>" alt="ILMA Education Consultancy Logo" width="55" height="50">
          <div class="brand-text-wrap">
            <span class="brand-title">ILMA</span>
            <span class="brand-sub">Education Consultancy</span>
          </div>
        </a>

        <!-- Desktop Navigation -->
        <nav>
          <ul class="nav-menu">
            <li class="nav-item">
              <a href="<?php echo esc_url(home_url('/')); ?>" class="nav-link <?php echo is_front_page() ? 'active' : ''; ?>">Home</a>
            </li>
            
            <li class="nav-item">
              <a href="<?php echo esc_url(home_url('/about/')); ?>" class="nav-link <?php echo is_page('about') ? 'active' : ''; ?>">About Us</a>
            </li>

            <!-- Study Destinations Dropdown -->
            <li class="nav-item">
              <a href="<?php echo esc_url(home_url('/destinations/')); ?>" class="nav-link <?php echo (is_post_type_archive('destination') || is_singular('destination')) ? 'active' : ''; ?>">
                Study Destinations
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="6 9 12 15 18 9"></polyline></svg>
              </a>
              <ul class="dropdown-menu">
                <?php
                $dest_nav = get_posts(['post_type' => 'destination', 'posts_per_page' => 6, 'post_status' => 'publish', 'orderby' => 'menu_order ID', 'order' => 'ASC']);
                if (!empty($dest_nav)) {
                    foreach ($dest_nav as $d) {
                        $flag_code = strtolower(get_post_meta($d->ID, '_dest_code', true) ?: 'flag');
                        $flag_img = get_template_directory_uri() . '/assets/images/' . ($flag_code === 'uk' ? 'united-kingdom-1.png' : ($flag_code === 'ca' || $flag_code === 'canada' ? 'canada.png' : ($flag_code === 'us' || $flag_code === 'usa' ? 'united-states-of-america.png' : ($flag_code === 'my' || $flag_code === 'malaysia' ? 'malaysia.png' : ($flag_code === 'nz' || $flag_code === 'new-zealand' ? 'new-zealand.png' : 'flag.png')))));
                        ?>
                        <li>
                          <a href="<?php echo esc_url(get_permalink($d->ID)); ?>" class="dropdown-link">
                            <img src="<?php echo esc_url($flag_img); ?>" alt="<?php echo esc_attr($d->post_title); ?> Flag" width="20" height="14">
                            <span>Study in <?php echo esc_html($d->post_title); ?></span>
                          </a>
                        </li>
                        <?php
                    }
                }
                ?>
                <li style="border-top: 1px solid var(--surface-200); margin-top: 0.25rem; padding-top: 0.25rem;">
                  <a href="<?php echo esc_url(home_url('/destinations/')); ?>" class="dropdown-link" style="color: var(--primary); font-weight: 700;">
                    <span>View All 6 Destinations →</span>
                  </a>
                </li>
              </ul>
            </li>

            <!-- Services Dropdown -->
            <li class="nav-item">
              <a href="<?php echo esc_url(home_url('/services/')); ?>" class="nav-link <?php echo (is_post_type_archive('service') || is_singular('service')) ? 'active' : ''; ?>">
                Services
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="6 9 12 15 18 9"></polyline></svg>
              </a>
              <ul class="dropdown-menu">
                <?php
                $serv_nav = get_posts(['post_type' => 'service', 'posts_per_page' => 6, 'post_status' => 'publish', 'orderby' => 'menu_order ID', 'order' => 'ASC']);
                if (!empty($serv_nav)) {
                    foreach ($serv_nav as $s) {
                        ?>
                        <li><a href="<?php echo esc_url(get_permalink($s->ID)); ?>" class="dropdown-link"><?php echo esc_html($s->post_title); ?></a></li>
                        <?php
                    }
                }
                ?>
                <li style="border-top: 1px solid var(--surface-200); margin-top: 0.25rem; padding-top: 0.25rem;">
                  <a href="<?php echo esc_url(home_url('/services/')); ?>" class="dropdown-link" style="color: var(--primary); font-weight: 700;">
                    <span>All Services & Process →</span>
                  </a>
                </li>
              </ul>
            </li>

            <li class="nav-item">
              <a href="<?php echo esc_url(home_url('/blogs/')); ?>" class="nav-link <?php echo (is_home() || is_singular('post')) ? 'active' : ''; ?>">Blogs</a>
            </li>

            <li class="nav-item">
              <a href="<?php echo esc_url(home_url('/contact/')); ?>" class="nav-link <?php echo is_page('contact') ? 'active' : ''; ?>">Contact</a>
            </li>
          </ul>
        </nav>

        <!-- Header Actions -->
        <div class="header-actions">
          <a href="<?php echo esc_url(home_url('/reserve-consultation/')); ?>" class="btn btn-outline btn-sm" style="font-weight: 700;">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg>
            Reserve Slot
          </a>

          <button type="button" class="btn btn-accent btn-sm open-consultancy-modal" style="font-weight: 700;">
            <span>Free Consultancy</span>
          </button>

          <!-- Mobile Toggle Button -->
          <button class="mobile-menu-toggle" aria-label="Open Mobile Menu">
            <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><line x1="3" y1="12" x2="21" y2="12"></line><line x1="3" y1="6" x2="21" y2="6"></line><line x1="3" y1="18" x2="21" y2="18"></line></svg>
          </button>
        </div>

      </div>
    </div>
  </header>

  <!-- Mobile Drawer Menu -->
  <div class="drawer-backdrop"></div>
  <aside class="mobile-drawer">
    <div class="drawer-header">
      <div class="brand-logo">
        <img src="<?php echo esc_url($logo_rgb); ?>" alt="ILMA Logo" width="45" height="40">
        <div class="brand-text-wrap">
          <span class="brand-title">ILMA</span>
          <span class="brand-sub">Education Consultancy</span>
        </div>
      </div>
      <button class="close-drawer-btn" style="background: none; border: none; cursor: pointer; color: var(--text-main); font-size: 1.5rem;">✕</button>
    </div>

    <ul class="mobile-nav-list">
      <li><a href="<?php echo esc_url(home_url('/')); ?>" class="mobile-nav-link">Home</a></li>
      <li><a href="<?php echo esc_url(home_url('/about/')); ?>" class="mobile-nav-link">About Us</a></li>
      <li><a href="<?php echo esc_url(home_url('/destinations/')); ?>" class="mobile-nav-link">Study Destinations (6 Countries)</a></li>
      <li><a href="<?php echo esc_url(home_url('/services/')); ?>" class="mobile-nav-link">Consultancy Services</a></li>
      <li><a href="<?php echo esc_url(home_url('/reserve-consultation/')); ?>" class="mobile-nav-link" style="color: var(--primary); font-weight: 700;">Reserve In-Person Consultation</a></li>
      <li><a href="<?php echo esc_url(home_url('/blogs/')); ?>" class="mobile-nav-link">Blogs & Guides</a></li>
      <li><a href="<?php echo esc_url(home_url('/contact/')); ?>" class="mobile-nav-link">Contact Us</a></li>
    </ul>

    <div style="margin-top: 2rem; padding-top: 1.5rem; border-top: 1px solid var(--surface-200);">
      <button type="button" class="btn btn-accent btn-block open-consultancy-modal" style="margin-bottom: 0.75rem;">
        Get Free Consultancy
      </button>
      <a href="tel:<?php echo esc_attr($phone1); ?>" class="btn btn-outline btn-block" style="font-size: 0.85rem;">
        📞 Call <?php echo esc_html($phone1); ?>
      </a>
    </div>
  </aside>
